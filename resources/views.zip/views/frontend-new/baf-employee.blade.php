<div class="row" >
                           
                                 <div class="col">
                                     <label for="inputEmail4">Name Of Service Holder<span style="color: red">*</span></label>
                                    <input type="text" class="form-control" name="service_holder_name" id="service_holder_name" required="" placeholder="Name of service Holder">
                                 </div>
                                 <div class="col">
                                 <label for="inputEmail4">Rank/Designation<span style="color: red">*</span></label>
                                 <input type="text" class="form-control" required="" name="name_of_service" id="name_of_service" placeholder="Rank/Designation">
                                 </div>
                             
                           
</div>
<br/>
<div class="row" >
                           
                                 <div class="col">
                                     <label for="inputEmail4">Service Number<span style="color: red">*</span></label>
                                    <input type="text" class="form-control" required="" name="service_name" id="service_name" placeholder="Service number">
                                 </div>
                                 <div class="col">
                                     <label for="inputEmail4">Present Office Address<span style="color: red">*</span></label>
                                    <input type="text" class="form-control" name="office_address" id="office_address" placeholder="Present office Address">
                                 </div>
                             
                           
</div>
<br/>

<div class="row" >
                                <div class="col">
                                    <label for="inputEmail4">Certification/Testimonial From Office (jpg,jpeg,png format)<span style="color: red">*</span>(File size max 200 KB)</label>
                                    <input type="file" class="form-control"  name="arm_certification" placeholder="Certification/Testimonial">
                                    <input type="hidden" class="form-control"  id="arm_certification_old" name="arm_certification_old" placeholder="Certification/Testimonial">
                                 </div>
                                 <div class="col">
                                    
                                 </div>
                                 
                             
                           
</div>