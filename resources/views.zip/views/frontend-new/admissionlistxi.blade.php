@extends('frontend-new.layout')
@section('content')
<style>
   .form-check{
      border-bottom: 1px solid #eee;
      font-size: 13px;
      padding: 5px;
      
   }
   .form-check a{
      color: black!important;
   }
   .form-check a:hover{
      color: #337AB7!important;
      font-weight: bold;
   }
   .sidecourse-title a{
      font-size: 16px;
      font-weight: bold;
   }
   @media (min-width: 768px) {
      .modal-content{
         width: 620px!important;
      }
   }
   .onlineformbtns {
    border-radius: 30px !important;
    padding: 7px 20px;
    border: 0;
    display: inline-block;
    font-size: 14px;
    border-radius: 30px;
    background: #337AB7;
    text-decoration: none !important;
    color: #fff !important;
    text-align: center;
    /* line-height: 24px; */
    transition: all 0.5s ease 0s;
    box-shadow: 0px 5px 25px 0px rgba(189, 7, 69, 0.41);
}
.mdbtn {
    width: 114px;
    margin-top: 2px;
}
.form-check .form-check-input {
    float: left;
    margin-left: 0em!important;
}
table{
   width: 35%;
}
.noborder tbody,.noborder td,.noborder tr{
   border: none!important;
}
.form-check {
    border-bottom: 0px solid #eee;
    font-size: 13px;
    padding: 1px;
}
.modal-body p {
    margin-top: 0;
    margin-bottom: .2rem;
}
.background-image table{
   width: 310px!important;
   text-align: center;
   margin: 0px auto;
   border: 0px solid !important; 
   --bs-table-bg: transparent;
}
.findAdmitcardt{
         width: 195px!important;
         text-align: center;
         margin: 0px auto;
         border: 0px solid !important; 
         --bs-table-bg: transparent;
}
@media (min-width: 768px) {
    .modal-content {
        width: 800px !important;
    }
    .modal-dialog{
      margin-left: 18%;
    }
}
.background-image {
    background-image: url({{asset('public/062.png')}});
    background-size: cover; /* Make the background cover the entire area */
    background-repeat: no-repeat; /* Prevent the background from repeating */
    background-position: center; /* Center the background image */
    padding: 0px!important;
    margin: 0px!important;
    max-width: 100%!important;
}
@media (max-width: 600px) {
   .modal-dialog{
      margin-left: 5%;
    }
    .modal-content {
        width: 90% !important;
    }
    h3, .h3,h4, .h4 {
      font-size: calc(.808125rem + 0.3375vw);
   }
   h4 span{
      font-size: 14px!important;
   }
   .btn {
         box-shadow: 0 0.25rem 0 rgba(0, 0, 0, 0.1);
         font-size: .7rem;
      }
      .background-image table{
         width: 240px!important;
         text-align: center;
         margin: 0px auto;
         border: 0px solid !important; 
        
      }
      table.findAdmitcardt{
         width: 145px!important;
         text-align: center;
         margin: 0px auto;
         border: 0px solid !important; 
         
      }
      .background-image {
         background-image: url({{asset('public/kg-admission-mobile.jpg')}});
         background-size: cover; /* Make the background cover the entire area */
         background-repeat: no-repeat; /* Prevent the background from repeating */
         background-position: center; /* Center the background image */
         padding: 0px!important;
         margin: 0px!important;
         max-width: 100%!important;
      }
      .modal-content {
         width: 100% !important;
      }
      .modal-dialog{
         margin-left: 0%;
      }
}
.width-100{
   width: 100%;
}
p {
    font-size: 1.175rem;
    color: #666;
    font-weight: bold;
}
label {
    margin-bottom: 0.2rem;
}
.background-image tr, .background-image tbody, .background-image td,.background-image .table {
    
     border: 0px solid !important; 
}

@media (min-width: 768px) {
   .background-image {
      min-height: 455px;
   }
}


.btn:hover{
   color: black!important;
}
.form-check-input {
   
    border: var(--bs-border-width) solid #1d1d1d;
}
.row {
    --bs-gutter-x: .5rem;
    --bs-gutter-y: 0;
    display: flex;
    flex-wrap: wrap;
    margin-top: calc(-1* var(--bs-gutter-y));
    margin-right: calc(var(--bs-gutter-x));
    margin-left: calc(var(--bs-gutter-x));
}
</style>
<div class="container spacet20 " >
   <div class="row">
      <div class="col-md-12 spacet60 pt-0-mobile">
         
        
         <div class="row">
            <div class="container spaceb50">
               <div class="row">
                  
                  
                  <div class="refine-categ-header " style="margin-top: 10px;">
                    
                  <h3 style="text-align: center">Online Admission (অনলাইন ভর্তি) </h3>
                    <h4 style="text-align: center"> <a href="{{asset('public/admissionpdf/Onine Admission.pdf')}}" target="_blank">Admission Instruction (ভর্তির নির্দেশনা)</a> </h4>
                    <h4 style="text-align: center"> <img title="Hotline Number" src="{{asset('public/call-thumbnail.png')}}" style="height: 25px" /> <a href="tel:01759536622" style="color: red;font-weight: bold;">01759536622, </a><a href="tel:01777521159" style="color: red;font-weight: bold;">01777521159</a> </h4>
                    <table class="table table-striped table-bordered">
                     <thead>
                        <tr>
                           <th>SL</th>
                           <th>Class</th>
                           <th>Version</th>
                           <th>Session</th>
                          
                           <th>Date</th>
                           <th>Number Of Seat</th>
                           <th>Amount</th>
                           <th>Action</th>
                        </tr>
                     </thead>
                     <tbody>
                        @foreach($admissiondata as $key=>$admission)
                        <tr>
                           <td>{{$key+1}}</td>
                           <td>{{$admission->class->class_name}}</td>
                           <td>{{$admission->version->version_name}}</td>
                           <td>{{($admission->class->class_code==11)?($session->session_name.'-'.((int)$session->session_name+1)):$admission->session->session_name}}</td>
                           
                           <td>Start Date:{{$admission->start_date}}<br/><span style="color: red;font-weight: bold">End Date:{{$admission->end_date}}</span></td>
                           <td>{{$admission->number_of_admission}}</td>
                           <td>{{$admission->price}}৳</td>
                           <td>
                              @if($admission->class->class_code==11)
                                 <a href="javascript:void(0)" 
                                 data-class_id="{{$admission->class_id}}" 
                                 data-session_id="{{$admission->session_id}}" 
                                  data-versionid="{{$admission->version_id}}" data-version="{{$admission->version->version_name}}"   class="onlineformbtn mdbtn mb12" name="search" id="search_btn">Registration</a>
                              @else 

                              @endif
                              </td>
                        </tr>
                        @endforeach
                        
                     </tbody>
                  </table>
                  <table class="table">
                     <tr><td style="text-align: center;border: none;">
                     <a class="onlineformbtn" href="{{route('login')}}" style="">Already Registered Click Here</a>
                     </td></tr>
                  </table>
                  
                  </div>
                  <!--./refine-categ-header--> 
                  
               </div>
               <!--./row-->
            </div>
            <!--./container-->
         </div>
                    
      </div>
   </div>
   <!--./row-->
</div>


   <div id="checkOnlineAdmissionStatus" class="modal fade" role="dialog" tabindex="-1">
         <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
               <div class="modal-header modal-header-small">
               
               <h4 style="width: 90%;text-align:center"><span id="version_name" style="color: red; font-weight: bold;font-size:17px!important"></span></h4>
               <button type="button" class="close closebtnmodal" data-dismiss="modal">&times;</button>
               </div>
               <form action="{{route('admissionData')}}"  method="post" enctype="multipart/form-data" class="onlineform" id="checkstatusform">
               <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
               <input type="hidden" name="version_id" id="version_id" value="" />
               <input type="hidden" name="class_id" id="class_id" value="" />
               <input type="hidden" name="session_id" id="session_id" value="" />
                  <div class="modal-body" style="padding:0px">
                    <div class="row" >
                            
                            <div class="col">
                            <label for="inputEmail4">SSC Roll Number (এসএসসি রোল নম্বর)<span style="color: red">*</span></label>
                                <input type="text" class="form-control" id="roll_number" value="{{old('roll_number')}}" required="" name="roll_number" placeholder="SSC Roll Number (এসএসসি রোল নম্বর)">
                            </div>
                            <div class="col">
                            <label for="inputEmail4">Education Board (শিক্ষাবোর্ড)<span style="color: red">*</span></label>
                                <select class="form-control" name="board_id" id="board_id">

                              <option value=""> Select Education Board (শিক্ষাবোর্ড নির্বাচন করুণ) </option>
                                            <option value="Dhaka">Dhaka (ঢাকা)</option>
                                            <option value="Rajshahi">Rajshahi (রাজশাহী)</option>
                                            <option value="Cumilla">Cumilla (কুমিল্লা)</option>
                                            <option value="Jashore">Jashore (যশোর)</option>
                                            <option value="Chattogram">Chattogram (চট্টগ্রাম)</option>
                                            <option value="Barishal">Barishal (বরিশাল)</option>
                                            <option value="Sylhet">Sylhet (সিলেট)</option>
								            <option value="Mymensingh">Mymensingh (ময়মনসিংহ)</option>
                                            <option value="Dinajpur">Dinajpur (দিনাজপুর)</option>
                                            <option value="Madrasah">Madrasah (মাদ্রাসা)</option>
                                            <option value="BTEB">Bangladesh Technical Education (বাংলাদেশ কারিগরি শিক্ষা বোর্ড)</option>
                                            <option value="BOU">BOU (বাউবি)</option>
                                        </select>
                            </div>
                        
                        
                    </div>
                    <div class="row" >
                            
                            <div class="col">
                            <label for="inputEmail4">Full Name (সম্পূর্ণ নাম)<span style="color: red">*</span></label>
                                <input type="text" readonly="" class="form-control" value="{{old('full_name')}}" required="" id="full_name" name="full_name" placeholder="Name">
                            </div>
                            <div class="col">
                            <label for="inputEmail4">Group (বিভাগ)<span style="color: red">*</span></label>
                            <input type="text" readonly="" class="form-control" value="{{old('group_name')}}" required="" id="group_name" name="group_name" placeholder="Group">
                            </div>
                        
                        
                    </div>
                     
                    
                     
                  </div>
                  <div class="modal-footer">
                  <button type="button" class="onlineformbtns mdbtn" data-bs-dismiss="modal">Close</button>
                   <button type="submit" class="onlineformbtns mdbtn" >Submit</button>
                  </div>
               </form>
            </div>
         </div>
   </div>
<script>
  $(document).ready(function() {
    $('#dob').on('change', function() {
      let category_id = $('input[name="category_id"]:checked').val();

       
        var dob = new Date($(this).val());
		if (!isNaN(dob.getTime())) { // Check if the date is valid
			var today = new Date(2025, 0, 1); // February 1, 2025

			// Calculate the age in terms of years, months, and days
			var years = today.getFullYear() - dob.getFullYear();
			var months = today.getMonth() - dob.getMonth();
			var days = today.getDate() - dob.getDate();

			// Adjust if the birth date hasn't occurred yet this month
			if (days < 0) {
				months--;
				// Get the last day of the previous month
				var lastDayOfPrevMonth = new Date(today.getFullYear(), today.getMonth(), 0).getDate();
				days += lastDayOfPrevMonth;
			}

			// Adjust if the birth month hasn't occurred yet this year
			if (months < 0) {
				years--;
				months += 12;
			}

			// Convert the calculated age to total days for comparison
			var totalAgeDays = years * 365 + months * 30 + days;

			// Minimum age: 4 years, 11 months, and 15 days
			var minAgeDays = (4 * 365) + (11 * 30) + 15;
			// Maximum age: 6 years and 15 days
			var maxAgeDays = (6 * 365) + 15;

			// Check if the total days fall within the valid range
			if ((totalAgeDays >= minAgeDays && totalAgeDays <= maxAgeDays) || (category_id==2 || category_id==4)) {
				$('#age').text(years + ' years, ' + months + ' months, ' + days + ' days').css('color', 'green');
				$('#message').text('Age is within the valid range').css('color', 'green');
			} else {
				Swal.fire({
					title: "Error",
					text: 'Age is not within the valid range',
					icon: "warning"
				});

				$('#age').text('');
				$(this).val('');
				$('#message').text('Age is not within the valid range').css('color', 'red');
			}
		} else {
			$('#message').text('Please select a valid date');
		}
    });
});


@if ($errors->any())
      
       @php 
         $text='';
         foreach ($errors->all() as $error){
            $text.='<p>'.$error.'</p>';
         }
       @endphp
         
        
      Swal.fire({
         title: "Warning!",
         html: "{!!$text!!}",
         icon: "warning"
      });
    
@endif

   @if(Session::get('warning'))
      
      Swal.fire({
         title: "Warning!",
         html: "{!!Session::get('warning')!!}",
         icon: "warning"
      });
      
   @endif
   $(function(){
      
      $(document.body).on('click','.kgadmission',function(){
         var versionid=$(this).data('versionid');
         var class_id=$(this).data('class_id');
         var session_id=$(this).data('session_id');
         var amount=$(this).data('amount');
         $('#versionid').val(versionid)
         $('#classid').val(class_id)
         $('#sessionid').val(session_id)
         $('#amount').val(amount)
         if(versionid==1){
            $('#versiontext').text('ভার্সন বাংলা');
         }else{
            $('#versiontext').text('Version English');
         }
         $('#exampleModalLong').modal('show');
      });
      $(document.body).on('click','.findAdmitcard',function(){
        
         $('#exampleModal').modal('show');
      });
      $(document.body).on('click','.onlineformbtn',function(){
         var versionid=$(this).data('versionid');
         var version_name=$(this).data('version');
         var class_id=$(this).data('class_id');
         var session_id=$(this).data('session_id');
         var price=$(this).data('price');
         $('#version_id').val(versionid);
         $('#class_id').val(class_id);
         $('#session_id').val(session_id);
         $('#price').val(price);
         var text='';
         if(versionid==1){
            text="XI Class Admission-Bangla Version<br/> (একাদশ শ্রেণিতে ভর্তি-বাংলা ভার্শন)"
         }else{
            text="XI Class Admission-English Version<br/> (একাদশ শ্রেণিতে ভর্তি-ইংরেজি ভার্শন)"
         }
         $('#version_name').html(text);
         $('#checkOnlineAdmissionStatus').modal('show'); 
      });
      $(document.body).on('input','#roll_number',function(){
        
         var roll_number=$('#roll_number').val();
         
         
         var board_id=$('#board_id').val();
        
         var url="{{route('checkRollRegistrationNumber')}}";
         if(roll_number?.length==6 && board_id){
            $.LoadingOverlay("show");
         $.ajax({
                type: "post",
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')},
                url: url,
                data:{"_token": "{{ csrf_token() }}",roll_number,board_id},
                success: function(response){
                 
                  $.LoadingOverlay("hide");
                  if(response==0){
                    
                     Swal.fire({
                        title: "Error",
                        text: 'Roll number or Board not found in BAF Shaheen College Dhaka Database',
                        icon: "warning"
                    });
                    $('#roll_number').val('');
                    $('#board_id').val('');
                  }else if(response==2){
                    
                     Swal.fire({
                        title: "BAF Shaheen College Dhaka",
                        text: 'Congratulations!  You have got a chance to get admission at BAF Shaheen college Dhaka by EQ/FQ. Contact College Office with the necessary documents for verification.',
                        icon: "success"
                    });
                    $('#roll_number').val('');
                    $('#board_id').val('');
                  }else if(response==1){
                     
                     Swal.fire({
                        title: "Error",
                        text: 'Allready applied',
                        icon: "warning"
                    });
                    $('#roll_number').val('');
                    $('#board_id').val('');
                  }else{
                     var data=jQuery.parseJSON( response )
                     $('#full_name').val(data.full_name);
                     $('#group_name').val(data.group_name);
                  }
                     
                   
                  
                },
                error: function(data, errorThrown)
                {
                  $.LoadingOverlay("hide");
                    Swal.fire({
                        title: "Error",
                        text: errorThrown,
                        icon: "warning"
                    });
                    $('#roll_number').val('');
                    $('#board_id').val('');
                }
            });
         }
      });
      $(document.body).on('submit','#checkadmissionstatus',function(e){
     

         e.preventDefault(); // avoid to execute the actual submit of the form.

         var form = $(this);
         var actionUrl = form.attr('action');
         $.LoadingOverlay("show");
         $.ajax({
            type: "POST",
            url: actionUrl,
            data: form.serialize(), // serializes the form's elements.
            success: function(data)
            {
               $.LoadingOverlay("hide");
               getPayment(data); // show response from the php script.
            }
         });

      });
      $(document.body).on('change','.category',function(){
         
         var category_id=$(this).val();
         $('#dob').val('');
         $('#age').html('');
         $('#message').html('');
         var url="{{route('getCategoryView')}}";
         $.ajax({
                type: "post",
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')},
                url: url,
                data:{"_token": "{{ csrf_token() }}",category_id},
                success: function(response){
                  
                  $.LoadingOverlay("hide");
                  console.log(response);
                  $('#categoryview').html(response);
                  
                },
                error: function(data, errorThrown)
                {
                  $.LoadingOverlay("hide");
                    Swal.fire({
                        title: "Error",
                        text: errorThrown,
                        icon: "warning"
                    });
                    $('#categoryview').html('');
                    
                }
            });

      });
      $(document.body).on('change','#onlineformbtn',function(){

      });
      $(document.body).on('change','#board_id',function(){
         var roll_number=$('#roll_number').val();
        
         
         var board_id=$('#board_id').val();
         
         var url="{{route('checkRollRegistrationNumber')}}";
         if(roll_number?.length==6 && board_id){
            $.LoadingOverlay("show");
            $.ajax({
                type: "post",
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')},
                url: url,
                data:{"_token": "{{ csrf_token() }}",roll_number,board_id},
                success: function(response){
                  
                  $.LoadingOverlay("hide");
                  if(response==0){
                     Swal.fire({
                        title: "Error",
                        text: 'Roll number or Board not found in BAF Shaheen College Dhaka Database',
                        icon: "warning"
                    });
                    
                   
                  }else if(response==1){
                     
                     Swal.fire({
                        title: "Error",
                        text: 'Allready applied',
                        icon: "warning"
                    });
                     
                  }else if(response==2){
                   
                     Swal.fire({
                        title: "BAF Shaheen College Dhaka",
                        text: 'Congratulations!  You have got a chance to get admission at BAF Shaheen college Dhaka by EQ/FQ. Contact College Office with the necessary documents for verification.',
                        icon: "success"
                    });
                     
                  }else{
                     var data=jQuery.parseJSON( response )
                     $('#full_name').val(data.full_name);
                     $('#group_name').val(data.group_name);
                  }
                     
                   
                  
                },
                error: function(data, errorThrown)
                {
                  $.LoadingOverlay("hide");
                    Swal.fire({
                        title: "Error",
                        text: errorThrown,
                        icon: "warning"
                    });
                    
                }
            });
         }
      });
   });
</script>
@endsection