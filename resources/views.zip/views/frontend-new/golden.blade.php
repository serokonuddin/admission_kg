<div class="row" >
                           
                                 <div class="col">
                                     <label for="inputEmail4">GEN ID<span style="color: red">*</span></label>
                                    <input type="text" class="form-control" id="gen_id" name="gen_id" required="" placeholder="Golden Eagle ID">
                                 </div>
                                 <div class="col">
                                 <label for="inputEmail4">Section<span style="color: red">*</span></label>
                                 <input type="text" class="form-control" id="section" name="section" required="" placeholder="Section">
                                 </div>
                             
                           
</div>