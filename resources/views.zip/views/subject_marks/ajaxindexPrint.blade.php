
    <style>
        .table-container {
            width: 100%;
            height: 100vh; /* Set height for the scrollable part */
            overflow: auto;
            border: 1px solid #ccc;
            }

            table {
            width: 100%;
            border-collapse: collapse;
            }

            th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: center;
            }
            td:nth-child(1),
            td:nth-child(2),
            td:nth-child(3) {
            position: sticky;
            left: 0;
            background-color: #f2f2f2;
            z-index: 3;
            }

            th:nth-child(1),
            th:nth-child(2),
            th:nth-child(3) {
            position: sticky;
            left: 0;
            background-color: #f2f2f2;
            z-index: 1;
            }

            /* Layer the columns properly */
            

            /* Optional: Freeze the table header */
            

            /* Set the width of the table header cells */
            thead  {
            position: sticky;
            top: 0;
            background-color: #f2f2f2;
            z-index: 1;
            }
            .table-container input{
                min-width: 80px;
            }
            .none{
                display:none;
            }
            .table-no-bordered th, .table-no-bordered td {
                border: 0px solid #fff;
            }
    </style>
    <table class="table table-striped table-no-bordered">
      <thead>
        <tr>
            @php 
            $classroman=array(
                                            '0'=>'KG',
                                            '1'=>'I',
                                            '2'=>'II',
                                            '3'=>'III',
                                            '4'=>'IV',
                                            '5'=>'V',
                                            '6'=>'VI',
                                            '7'=>'VII',
                                            '8'=>'VIII',
                                            '9'=>'IX',
                                            '10'=>'X',
                                            '11'=>'XI',
                                            '12'=>'XII',
                                            ''=>''
                                        );
            @endphp
            <td style="width: 100%;text-align:center">
                <img style="width: 80px" src="{{asset('public/frontend/uploads/school_content/logo/front_logo-608ff44a5f8f07.35255544.png')}}" />
                <h3 style="margin-top: 0px; margin-bottom: 4px; color:#0484BD; font-size:21px; font-weight:bold; white-space: nowrap;">BAF Shaheen College Dhaka</h3>
                <span style="text-align:center; margin-top: 0px; margin-bottom: 0px; font-size:14px;">
                        Dhaka Cantonment, Dhaka-1206
                </span>
                <br/>
                <span style="text-align:center; margin-top: 0px; margin-bottom: 0px; font-size:16px;">
                {{$subject->subject_name.'('.$subject->subject_wise_class->subject_code.')'}}<span style="font-size: 0.8em">: {{(!empty($students))?count($students):count($subjectMarks)}} students found
                <br/>
                Section: {{$section->section_name}} 
                <br/>
                Exam: {{$exam->exam_title}} (Class {{$classroman[$exam->class_code]}})
                </span>
                
            </td>
           
        </tr>
        </thead>
    </table>
    <table class="table " >
                        <thead>
                        <tr>
                            <th rowspan="2">SL</th>
                            <th rowspan="2">Student</th>
                            <th rowspan="2">Roll</th>
                            @php 
                             $max_assigment=10;
                             $max_project=10;
                             $max_work=10;
                             if($subject_id==117){
                                $max_project=5;
                                $max_work=15;
                             }
                             $total_mark=0;
                             $pass_mark=0;
                            @endphp
                            @foreach($subject->subjectMarkTerms as $term)
                            @php 
                            
                             $total_mark+=$term->total_mark;
                             $pass_mark+=$term->pass_mark;
                            @endphp
                            @if($term->marks_for==0 && $class_code!=4 && $class_code!=5)
                            <th colspan="4" style="text-align: center">
                            @elseif($term->marks_for>0)
                            <th colspan="3" style="text-align: center">
                            @else
                            <th  style="text-align: center">
                            @endif
                            @if($term->marks_for!=0)
                           
                            @endif
                                @if($term->marks_for==0)
                                {{($class_code>5)?'Formative Assesment (FA)':'CT'}}
                                @elseif($term->marks_for==1)
                                {{($class_code>5)?'Summative Assesment (SA)':'CQ'}}
                                @elseif($term->marks_for==2)
                                MCQ
                                @else 
                                Practical
                                @endif
                                <br/>(T:{{$term->total_mark}}, P:{{$term->pass_mark}})
                            </th>
                            @endforeach
                            <!-- <th colspan="3" style="text-align: center">MCQ <br/>(T:25.00, P:8.00)</th>
                            <th colspan="3" style="text-align: center">Practical<br/>(T:25.00, P:8.00)</th> -->
                            <!-- <th rowspan="2">Total Mark <br/> (T:{{$total_mark}}, P:{{$pass_mark}})</th>
                            <th rowspan="2">Conv ({{$class_percentage->percentage}})</th>
                            <th rowspan="2">CA/CT + Conv ({{$class_percentage->percentage}})</th>
                            <th rowspan="2">GPA Point</th>
                            <th rowspan="2">GPA</th> -->
                            
                        </tr>
                        <tr>
                            @foreach($subject->subjectMarkTerms as $term)
                            @if($term->marks_for==0)
                            @if($class_code==12 || $class_code==11)
                            <th>CT 1</th>
                            <th>CT 2</th>
                            <th>Quiz</th>
                            <th>Total</th>
                            @else
                            <th class="{{($class_code>=4 && $class_code<=5)?'none':''}}">Assigment <br/> Work</th>
                            <th class="{{($class_code>=4 && $class_code<=5)?'none':''}}">Project <br/>Proposal</th>
                            <th class="{{($class_code>=4 && $class_code<=5)?'none':''}}">Class<br/> Work</th>
                            <th>CT/CA</th>
                            @endif
                            
                            @else 
                            <th>Obtained <br/> Marks</th>
                            <th>Grace <br/>Marks</th>
                            <th>Total<br/> Marks</th>
                            @endif
                            @endforeach
                            
                        </tr>
                    </thead>
                        <tbody>
                            @foreach($students as $student)
                           
                            <tr>
                                <td>
                                    {{$loop->index+1}}
                                    
                                     
                                </td>
                                <td>{{$student->first_name}}</td>
                                <td>{{$student->roll}}</td>
                                @php 
                                $total=0;
                                $subjectmark=$student->subjectwisemark[0]??array();
                                
                                @endphp
                                @foreach($subject->subjectMarkTerms as $key2=>$term)
                                
                                @if($class_code>5)
                                    @if($term->marks_for==0)
                                    
                                    <td>
                                    
                                    
                                    </td>
                                    <td>
                                   
                                    </td>

                                    <td  >
                                    
                                    
                                    </td>
                                    <td  >
                                    
                                    
                                    </td>
                                    @else
                                    @php 
                                        $obtained='';
                                        $grace='';
                                        $total='';
                                        if($term->marks_for==1){
                                            $obtained=$subjectmark->cq??'';
                                            $grace=$subjectmark->cq_grace??'';
                                            $total=$subjectmark->cq_total??'';
                                        }elseif($term->marks_for==2){
                                            $obtained=$subjectmark->mcq??'';
                                            $grace=$subjectmark->mcq_grace??'';
                                            $total=$subjectmark->mcq_total??'';
                                        }else{
                                            $obtained=$subjectmark->practical??'';
                                            $grace=$subjectmark->practical_grace??'';
                                            $total=$subjectmark->practical_total??'';
                                        }
                                    @endphp
                                    <td>
                                   
                                    
                                    </td>
                                    <td>
                                   
                                    </td>
                                    <td >
                                    
                                   
                                    </td>
                                    @endif
                                @elseif($class_code==4 || $class_code==5)
                                @if($term->marks_for==0)
                                    
                                    <td class="{{($class_code>=4 && $class_code<=5)?'none':''}}">
                                    
                                   
                                    </td>
                                    <td class="{{($class_code>=4 && $class_code<=5)?'none':''}}">
                                    
                                    </td>

                                    <td class="{{($class_code>=4 && $class_code<=5)?'none':''}}">
                                    
                                   
                                    </td>
                                    <td  >
                                    
                                    
                                    </td>
                                    @else
                                    @php 
                                        $obtained='';
                                        $grace='';
                                        $total='';
                                        if($term->marks_for==1){
                                            $obtained=$subjectmark->cq??'';
                                            $grace=$subjectmark->cq_grace??'';
                                            $total=$subjectmark->cq_total??'';
                                        }elseif($term->marks_for==2){
                                            $obtained=$subjectmark->mcq??'';
                                            $grace=$subjectmark->mcq_grace??'';
                                            $total=$subjectmark->mcq_total??'';
                                        }else{
                                            $obtained=$subjectmark->practical??'';
                                            $grace=$subjectmark->practical_grace??'';
                                            $total=$subjectmark->practical_total??'';
                                        }
                                    @endphp
                                    <td>
                                   
                                    
                                    </td>
                                    <td>
                                   
                                    </td>
                                    <td >
                                    
                                    
                                    </td>
                                    @endif
                                @endif
                                

                                @endforeach

                                <!-- <td  >
                                  <input  class="form-control marks    text-center " readonly="" value="{{$subjectmark->total??''}}" name="totalmark{{$student->student_code}}" id="totalmark{{$student->student_code}}"    type="text"  >
                                </td>
                                <td  >
                                <input  class="form-control marks    text-center " readonly="" value="{{$subjectmark->conv_total??''}}" name="conv{{$student->student_code}}" id="conv{{$student->student_code}}"    type="text"  >
                                </td>
                                <td >
                                <input  class="form-control marks    text-center " readonly="" value="{{$subjectmark->ct_conv_total??''}}" name="ctconv{{$student->student_code}}" id="ctconv{{$student->student_code}}"    type="text"  >
                                </td>
                                <td  >
                                <input  class="form-control marks    text-center " readonly="" value="{{$subjectmark->gpa_point??''}}" name="gpapoint{{$student->student_code}}" id="gpapoint{{$student->student_code}}"    type="text"  >
                                </td>
                                <td >
                                <input  class="form-control marks    text-center " readonly="" value="{{$subjectmark->gpa??''}}" name="gpa{{$student->student_code}}" id="gpa{{$student->student_code}}"    type="text"  >
                                </td> -->
                            </tr>
                            @endforeach
                        </tbody>

                    </table>
                   
                    