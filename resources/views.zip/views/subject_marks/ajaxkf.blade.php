<link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.print.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<h4 class="panel-title">{{ $subject->subject_name . '(' . $subject->subject_wise_class->subject_code . ')' }}<span
        style="font-size: 0.8em">: {{ !empty($students) ? count($students) : count($subjectMarks) }} students
        found</span>
</h4>
<style>
    .table-container {
        width: 100%;
        height: 100vh;
        /* Set height for the scrollable part */
        overflow: auto;
        border: 1px solid #ccc;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    th,
    td {
        border: 1px solid #ccc;
        padding: 8px;
        text-align: center;
    }

    td:nth-child(1),
    td:nth-child(2),
    td:nth-child(3) {
        position: sticky;
        left: 0;
        background-color: #f2f2f2;
        z-index: 3;
    }

    th:nth-child(1),
    th:nth-child(2),
    th:nth-child(3) {
        position: sticky;
        left: 0;
        background-color: #f2f2f2;
        z-index: 1;
    }

    /* Layer the columns properly */


    /* Optional: Freeze the table header */


    /* Set the width of the table header cells */
    thead {
        position: sticky;
        top: 0;
        background-color: #f2f2f2;
        z-index: 1;
    }

    .table-container input {
        min-width: 80px;
    }

    .none {
        display: none;
    }
</style>

<table class="table ">
    <thead>
        <tr>
            <th>SL</th>
            <th>Student</th>
            <th>Roll</th>
            @php
                $max_mark = 25;
                if ($subject_id == 117) {
                    $max_project = 5;
                    $max_work = 15;
                }

            @endphp


            <th style="text-align: center">

                CT 1

            </th>
            <th style="text-align: center">

                CT 2

            </th>

            <!-- <th colspan="3" style="text-align: center">MCQ <br/>(T:25.00, P:8.00)</th>
                            <th colspan="3" style="text-align: center">Practical<br/>(T:25.00, P:8.00)</th> -->
            <th>Total Mark </th>
            <th>Converted To</th>

            <th>GPA Point</th>
            <th>GPA</th>
        </tr>

    </thead>
    <tbody>
        @foreach ($students as $student)
            <tr>
                <td>
                    {{ $loop->index + 1 }}
                    <input type="hidden" value="{{ $student->student_code }}" name="student_code[]" />
                    <input type="hidden" value="{{ $student->version_id }}" name="version_id[]" />
                    <input type="hidden" value="{{ $student->group_id }}" name="group_id[]" />

                </td>
                <td>{{ $student->first_name }}</td>
                <td>{{ $student->roll }}</td>
                @php
                    $total = 0;
                    $subjectmark = $student->subjectwisemark[0] ?? [];
                    // var_dump($subjectmark);
                @endphp


                <td>

                    <input class="form-control marks ct1   text-center " value="{{ $subjectmark->ct1 ?? '' }}"
                        name="ct1{{ $student->student_code }}" id="ct1{{ $student->student_code }}"
                        data-student_code="{{ $student->student_code }}" data-maxvalue="{{ $max_mark }}"
                        data-marks_for="" type="text">
                </td>
                <td>
                    <input class="form-control marks ct2   text-center " value="{{ $subjectmark->ct2 ?? '' }}"
                        name="ct2{{ $student->student_code }}" id="ct2{{ $student->student_code }}"
                        data-student_code="{{ $student->student_code }}" data-maxvalue="{{ $max_mark }}"
                        data-marks_for="" type="text">
                </td>
                <td>
                    <input class="form-control marks text-center" readonly=""
                        value="{{ $subjectmark->total ?? '' }}" name="totalmark{{ $student->student_code }}"
                        id="totalmark{{ $student->student_code }}" type="text">
                </td>
                <td>
                    <input class="form-control marks    text-center " readonly=""
                        value="{{ $subjectmark->conv_total ?? '' }}" name="conv{{ $student->student_code }}"
                        id="conv{{ $student->student_code }}" type="text">
                </td>

                <td>
                    <input class="form-control marks    text-center " readonly=""
                        value="{{ $subjectmark->gpa_point ?? '' }}" name="gpapoint{{ $student->student_code }}"
                        id="gpapoint{{ $student->student_code }}" type="text">
                </td>
                <td>
                    <input class="form-control marks    text-center " readonly=""
                        value="{{ $subjectmark->gpa ?? '' }}" name="gpa{{ $student->student_code }}"
                        id="gpa{{ $student->student_code }}" type="text">
                </td>

            </tr>
        @endforeach
    </tbody>

</table>
<div class="mb-3  col-md-2">
    <label class="form-label" for="amount"> </label>
    <button type="submit" class="btn btn-primary form-control me-2 mt-1">Save</button>
</div>
<script>
    function getGPA(marks) {
        if (marks >= 80) {
            return 'A+'; // A+
        } else if (marks >= 70) {
            return 'A'; // A
        } else if (marks >= 60) {
            return 'A-'; // A-
        } else if (marks >= 50) {
            return 'B'; // B
        } else if (marks >= 40) {
            return 'C'; // C
        } else if (marks >= 33) {
            return 'D'; // D
        } else {
            return 'F'; // F
        }
    }
    function getGPAPoint(marks) {
        if (marks >= 80) {
            return 5.0; // A+
        } else if (marks >= 70) {
            return 4.0; // A
        } else if (marks >= 60) {
            return 3.5; // A-
        } else if (marks >= 50) {
            return 3.0; // B
        } else if (marks >= 40) {
            return 2.0; // C
        } else if (marks >= 33) {
            return 1.0; // D
        } else {
            return 0.0; // F
        }
    }
    $(document).ready(function() {
        $('#headerTable').DataTable({
            dom: 'Bfrtip',
            buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
            ]
        });
    });

    var Num = function(n, p = 2) {
        return +(parseFloat(n, 10) || 0).toFixed(p);
    }
    var Val = function($n, v) {
        var $n = $($n);
        return (arguments.length > 1) ? $n.val(Num(v) || '') : Num($n.val());
    }
    var isDefined = function(v) {
        return typeof(v) !== 'undefined';
    }

    $(document).ready(function() {

        function calculateSums() {
            var student_code = $(this).data('student_code');
            var maxvalue = $(this).data('maxvalue');
            var subject_id = $('#subject_id').val();
            var currentvalue = $(this).val();
            if (maxvalue < currentvalue) {
                $(this).val('');
                Swal.fire({
                    title: "Warning",
                    text: "Over The Maximum Value",
                    icon: "warning"
                });
            }
            // Sum of 4th, 5th, 6th TD inputs (CT1, CT2, CT3) and set in 7th TD input

            // let ct1 = Num($('input[name="ct1' + student_code + '"]').val());
            // let ct2 = Num($('input[name="ct2' + student_code + '"]').val());

            // let sum1 = ct1 + ct2;

            // NEW From Rezwan
            let ct1 = parseFloat($('input[name="ct1' + student_code + '"]').val()) ||
            0; // Safeguard against NaN
            let ct2 = parseFloat($('input[name="ct2' + student_code + '"]').val()) || 0;
            let sum1 = ct1 + ct2;
            sum1 = parseFloat(sum1.toFixed(2));

            $('input[name="totalmark' + student_code + '"]').val(sum1);

            // Convert 17th TD input to 70% and set value in 18th TD input
            let percentage70 = 0;
            let finalTotal = 0;
            if (subject_id == 39) {
                percentage70 = ct2;
                finalTotal = percentage70 * 4;
                $('input[name="conv' + student_code + '"]').val(percentage70);
            } else if (subject_id == 38) {
                percentage70 = ct2 * 2;
                $('input[name="conv' + student_code + '"]').val(percentage70);
                finalTotal = ct2 * 4;

            } else {
                percentage70 = Math.round((sum1 * 100) / 50);
                finalTotal = percentage70;
                $('input[name="conv' + student_code + '"]').val(percentage70);
            }


            // Sum of 18th and 7th TD input and set value in 19th TD input




            // Calculate GPA Point based on 19th TD input value and set in 20th TD input
            let gpaPoint = calculateGpaPoint(finalTotal);
            $('input[name="gpapoint' + student_code + '"]').val(gpaPoint);

            // Calculate GPA based on 19th TD input value and set in 21st TD input
            let gpa = calculateGpa(finalTotal);
            $('input[name="gpa' + student_code + '"]').val(gpa);

        }

        // Helper function to calculate GPA Point based on the final marks (example logic)
        function calculateGpaPoint(marks) {
            if (marks >= 80) {
                return 5.0; // A+
            } else if (marks >= 70) {
                return 4.0; // A
            } else if (marks >= 60) {
                return 3.5; // A-
            } else if (marks >= 50) {
                return 3.0; // B
            } else {
                return 0.0; // F
            }
        }

        // Helper function to calculate GPA (example logic)
        function calculateGpa(marks) {
            if (marks >= 80) {
                return 'A+'; // A+
            } else if (marks >= 70) {
                return 'A'; // A
            } else if (marks >= 60) {
                return 'A-'; // A-
            } else if (marks >= 50) {
                return 'B'; // B
            } else {
                return 'F'; // F
            }
        }

        // Attach event listener to relevant input fields
        $('input').on('input', calculateSums);
    });
</script>
