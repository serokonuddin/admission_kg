<footer class="content-footer footer bg-footer-theme">
    <div class="container-xxl d-flex flex-wrap  py-2 flex-md-row flex-column">
        <div class="mb-2 mb-md-0">
            © 2024,<a href="+01913366387" target="_blank" class="footer-link fw-medium">&nbsp; Shahin Tech | All Rights Reserved</a>
        </div>
    </div>
</footer>
