<style>
    .menu-item.highlight a {
        color: #154CC2 !important;
    }

    .blink {
        animation: blink-animation 1s steps(5, start) infinite;
        -webkit-animation: blink-animation 1s steps(5, start) infinite;
    }

    @keyframes blink-animation {
        to {
            visibility: hidden;
        }
    }

    @-webkit-keyframes blink-animation {
        to {
            visibility: hidden;
        }
    }

    .app-brand-text.demo {
        text-transform: uppercase !important;
    }
</style>
<ul class="menu-inner py-1">
    <!-- Dashboards -->
    <li class="menu-item {{ Session::get('activemenu') == 'dashboard' ? 'active open' : '' }}">
        <a href="{{ url('admin/dashboard') }}" class="menu-link ">
            <i class="menu-icon tf-icons bx bx-home-circle"></i>
            <div class="text-truncate" data-i18n="Dashboard">Dashboard</div>

        </a>

    </li>
    <!-- Layouts -->
    @if (Auth::user()->group_id == 4)
        <li class="menu-item {{ Session::get('activemenu') == 'profile' ? 'active open' : '' }}">
            <a href="{{ route('StudentProfile', 0) }}" class="menu-link ">
                <i class="menu-icon tf-icons bx bx-file"></i>
                <div class="text-truncate" data-i18n="Profile">Profile</div>
            </a>

        </li>

        {{-- <li class="menu-item {{(Session::get('activemenu')=='ic')?'active open':''}}">
      <a href="{{route('getidcard')}}"  class="menu-link ">
         <i class="menu-icon tf-icons bx bx-file"></i>
         <div class="text-truncate" data-i18n="ID Card">ID Card</div>
      </a>
   </li> --}}
        <li class="menu-item {{ Session::get('activemenu') == 'attendance' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-calendar"></i>
                <div class="text-truncate" data-i18n="Attendance">Attendance</div>
            </a>
            <ul class="menu-sub">

                <li class="menu-item {{ Session::get('activesubmenu') == 'ta' ? 'highlight blink' : '' }}">
                    <a href="{{ route('studentAttendanceparentAttendance') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Attendance">Attendance</div>
                    </a>
                </li>
            </ul>
        </li>
        <li class="menu-item {{ Session::get('activemenu') == 'academic' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-layout"></i>
                <div class="text-truncate" data-i18n="Academic Info">Academic Info</div>
            </a>
            <ul class="menu-sub">


                <li class="menu-item {{ Session::get('activesubmenu') == 'notice' ? 'highlight blink' : '' }}">
                    <a href="{{ route('studentNotice') }}" class="menu-link">
                        <!-- <a href="#" class="menu-link"> -->
                        <div class="text-truncate" data-i18n="Notice">Notice</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'routine' ? 'highlight blink' : '' }}">
                    <a href="{{ route('studentRouten') }}" class="menu-link">
                        <!-- <a href="#" class="menu-link"> -->
                        <div class="text-truncate" data-i18n="Routine">Routine</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'lessonplan' ? 'highlight blink' : '' }}">
                    <a href="{{ route('lessonPlanStudent') }}" class="menu-link">
                        <!-- <a href="#" class="menu-link"> -->
                        <div class="text-truncate" data-i18n="Lesson Plan">Lesson Plan</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'syllabus' ? 'highlight blink' : '' }}">
                    <a href="{{ route('studentSyllabus') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Syllabus">Syllabus</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'act' ? 'highlight blink' : '' }}">
                    <a href="{{ route('student.academicTranscript') }}" class="menu-link ">
                        <div class="text-truncate" data-i18n="Result">Result</div>
                    </a>
                </li>
                {{-- <li class="menu-item {{ Session::get('activesubmenu') == 'exam' ? 'highlight blink' : '' }}">
                    <a href="#" class="menu-link">
                        <div class="text-truncate" data-i18n="Exam">Exam</div>
                    </a>
                </li> --}}
            </ul>
        </li>
        <li class="menu-item {{ Session::get('activemenu') == 'leave' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-card"></i>
                <div class="text-truncate" data-i18n="Leave">Leave</div>
            </a>
            <ul class="menu-sub">

                <li class="menu-item {{ Session::get('activesubmenu') == 'lv' ? 'highlight blink' : '' }}">
                    <!-- <a href="#" class="menu-link"> -->
                    <a href="{{ route('documents.index') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Leave View">Leave View</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'lv' ? 'highlight blink' : '' }}">
                    <!-- <a href="#" class="menu-link"> -->
                    <a href="{{ route('documents.create') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Leave Apply">Leave Apply</div>
                    </a>
                </li>
            </ul>
        </li>
        <li class="menu-item {{ Session::get('activemenu') == 'salary' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-card"></i>
                <div class="text-truncate" data-i18n="Fees">Fees</div>
            </a>
            <ul class="menu-sub">

                <li class="menu-item {{ Session::get('activesubmenu') == 's' ? 'highlight blink' : '' }}">
                    <!-- <a href="#" class="menu-link"> -->
                    <a href="{{ route('studentFee') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Fees List">Fees List</div>
                    </a>
                </li>
            </ul>
        </li>
    @endif



    @if (Auth::user()->group_id == 7)
        <li class="menu-item {{ Session::get('activemenu') == 'admission' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div class="text-truncate" data-i18n="Admission">Admission</div>
            </a>
            <ul class="menu-sub">
                @if (Auth::user()->getMenu('boardList', 'name'))
                    <!-- <li class="menu-item {{ Session::get('activesubmenu') == 'bl' ? 'highlight blink' : '' }}">
            <a href="{{ route('boardList') }}" class="menu-link">
               <div class="text-truncate" data-i18n="Board List">Board List</div>
            </a>
         </li> -->
                @endif
                @if (Auth::user()->getMenu('kgAdmitList', 'name'))
                    <!-- <li class="menu-item {{ Session::get('activesubmenu') == 'kl' ? 'highlight blink' : '' }}">
            <a href="{{ route('kgAdmitList') }}" class="menu-link">
               <div class="text-truncate" data-i18n="Kg Admit List">Kg Admit List</div>
            </a>
         </li> -->
                @endif
                @if (Auth::user()->getMenu('admissionlist.index', 'name'))
                    <!-- <li class="menu-item {{ Session::get('activesubmenu') == 'al' ? 'highlight blink' : '' }}">
            <a href="{{ route('admissionlist.index') }}" class="menu-link">
               <div class="text-truncate" data-i18n="Applicant List">Applicant List</div>
            </a>
         </li> -->
                @endif
                @if (Auth::user()->getMenu('admissionOpen', 'name'))
                    <!-- <li class="menu-item {{ Session::get('activesubmenu') == 'oa' ? 'highlight blink' : '' }}">
            <a href="{{ route('admissionOpen') }}" class="menu-link">
               <div class="text-truncate" data-i18n="Open Admission">Open Admission </div>
            </a>
         </li> -->
                @endif
                @if (Auth::user()->getMenu('sectionWiseStudent', 'name'))
                    <!-- <li class="menu-item {{ Session::get('activesubmenu') == 'scws' ? 'highlight blink' : '' }}">
             <a href="{{ route('sectionWiseStudent') }}" class="menu-link">
                <div class="text-truncate" data-i18n="Section Wise Student">Section Wise Student</div>
             </a>
          </li> -->
                @endif
                <li class="menu-item {{ Session::get('activesubmenu') == 'na' ? 'highlight blink' : '' }}">
                    <a href="{{ route('collegeAdmission') }}" class="menu-link ">
                        {{-- <i class="menu-icon tf-icons bx bx-file"></i> --}}
                        <div class="text-truncate" data-i18n="New Admission">New Admission</div>
                    </a>

                </li>
                @if (Auth::user()->getMenu('admissionIdCard', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'adc' ? 'highlight blink' : '' }}">
                        <a href="{{ route('admissionIdCard') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="ID Card">ID Card</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('subjectWiseStudent', 'name'))
                    <!-- <li class="menu-item {{ Session::get('activesubmenu') == 'sws' ? 'highlight blink' : '' }}">
             <a href="{{ route('subjectWiseStudent') }}" class="menu-link">
                <div class="text-truncate" data-i18n="Subject Wise Student">Subject Wise Student</div>
             </a>
          </li> -->
                @endif

                <li class="menu-item {{ Session::get('activesubmenu') == 'scl' ? 'highlight blink' : '' }}">
                    <a href="{{ route('showCertificateList') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="TC">TC</div>
                    </a>
                </li>


                <li class="menu-item {{ Session::get('activesubmenu') == 'tcf' ? 'highlight blink' : '' }}">
                    <a href="{{ route('transferCertificate') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="TC Generate">TC Generate</div>
                    </a>
                </li>

                <li class="menu-item {{ Session::get('activesubmenu') == 'tml' ? 'highlight blink' : '' }}">
                    <a href="{{ route('testimonial.index') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Testimonial">Testimonial</div>
                    </a>
                </li>

                <li class="menu-item {{ Session::get('activesubmenu') == 'ks' ? 'active open' : '' }}">
                    <a href="{{ route('showStudentCounts') }}" class="menu-link ">
                        <div class="text-truncate" data-i18n="Primary Secondary Statistics">Primary Secondary
                            Statistics</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'cs' ? 'active open' : '' }}">
                    <a href="{{ route('admissionstatus') }}" class="menu-link ">
                        <div class="text-truncate" data-i18n="College Statistics">College Statistics</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'adc' ? 'highlight blink' : '' }}">
                    <a href="{{ route('admissionIdCard') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="ID Card">ID Card</div>
                    </a>
                </li>

            </ul>
        </li>
        {{-- <li class="menu-item {{ Session::get('activesubmenu') == 'smsc' ? 'active open' : '' }}">
            <a href="{{ route('sms.create') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-envelope"></i>
                <div class="text-truncate" data-i18n="Send SMS">Send SMS</div>
            </a>
        </li> --}}
        <li class="menu-item {{ Session::get('activesubmenu') == 'adc' ? 'active open' : '' }}">
            <a href="{{ route('admitcard') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-calendar"></i>
                <div class="text-truncate" data-i18n="Admit Card">Admit Card</div>
            </a>
        </li>
        <li class="menu-item {{ Session::get('activesubmenu') == 'as' ? 'active open' : '' }}">
            <a href="{{ route('attendanceSheet') }}" class="menu-link">
                <i class="bx bx-calendar-check me-2"></i>
                <div class="text-truncate" data-i18n="Attendance Sheet">Attendance Sheet</div>
            </a>
        </li>

        <li class="menu-item {{ Session::get('activesubmenu') == 'ul' ? 'active open' : '' }}">
            <a href="{{ route('users.index') }}" class="menu-link">
                <i class="bx bx-key me-2"></i>
                <div class="text-truncate" data-i18n="Resend password">Resend password</div>
            </a>
        </li>

    @endif

    @if (Auth::user()->group_id == 3)
        <li class="menu-item {{ Session::get('activemenu') == 'Profile' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-calendar"></i>
                <div class="text-truncate" data-i18n="Profile">Profile</div>
            </a>

            <ul class="menu-sub">

                <li class="menu-item {{ Session::get('activesubmenu') == 'profile' ? 'highlight blink' : '' }}">
                    <a href="{{ route('teacherProfile') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="My Profile">My Profile</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'cp' ? 'highlight blink' : '' }}">
                    <a href="{{ route('change.password.form') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Change Password">Change Password</div>
                    </a>
                </li>

            </ul>
        </li>

        <li class="menu-item {{ Session::get('activemenu') == 'Class' ? 'active open' : '' }}">
            <a href="{{ route('teacherClass') }}" class="menu-link ">
                <i class="menu-icon tf-icons bx bx-grid"></i>
                <div class="text-truncate" data-i18n="Class">Class</div>
            </a>

        </li>
        <li class="menu-item {{ Session::get('activemenu') == 'Routen' ? 'active open' : '' }}">
            <a href="{{ route('teacherRouten') }}" class="menu-link ">
                <i class="menu-icon tf-icons bx bx-file"></i>
                <div class="text-truncate" data-i18n="My Routine">My Routine</div>
            </a>

        </li>
        <li class="menu-item {{ Session::get('activemenu') == 'Student' ? 'active open' : '' }}">
            <a href="{{ route('teacherStudent') }}" class="menu-link ">
                <i class="menu-icon tf-icons bx bx-file"></i>
                <div class="text-truncate" data-i18n="Student">Student</div>
            </a>

        </li>



        @if (Auth::user()->id == 10881)
            <li class="menu-item {{ Session::get('activemenu') == 'ca' ? 'active open' : '' }}">
                <a href="{{ route('collegeAdmission') }}" class="menu-link ">
                    <i class="menu-icon tf-icons bx bx-file"></i>
                    <div class="text-truncate" data-i18n="College Admission">College Admission</div>
                </a>

            </li>
        @endif
        @if (Auth::user()->id == 10909)
            <li class="menu-item {{ Session::get('activemenu') == 'ks' ? 'active open' : '' }}">
                <a href="{{ route('showStudentCounts') }}" class="menu-link ">
                    <i class="menu-icon tf-icons bx bx-file"></i>
                    <div class="text-truncate" data-i18n="Student Statistics">Student Statistics</div>
                </a>

            </li>
        @endif
        <li class="menu-item {{ Session::get('activemenu') == 'attendance' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-calendar"></i>
                <div class="text-truncate" data-i18n="Attendance">Attendance</div>
            </a>
            <ul class="menu-sub">
                <li
                    class="menu-item {{ Session::get('activesubmenu') == 'Student Attendance' ? 'highlight blink' : '' }}">
                    <a href="{{ route('teacherStudentAttendance') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Student Attendance">Student Attendance</div>
                    </a>
                </li>
                <li
                    class="menu-item {{ Session::get('activesubmenu') == 'Student Attendance Report' ? 'highlight blink' : '' }}">
                    <a href="{{ route('teacherStudentAttendanceReport') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Attendance Report">Attendance Report
                        </div>
                    </a>
                </li>

                <li class="menu-item {{ Session::get('activesubmenu') == 'atr' ? 'highlight blink' : '' }}">
                    <a href="{{ route('attendance.reconcilation') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Attendance Reconciliation">Attendance Reconciliation
                        </div>
                    </a>
                </li>

                {{-- <li class="menu-item {{ Session::get('activesubmenu') == 'atreport' ? 'highlight blink' : '' }}">
                    <a href="{{ route('attendance.getStudent') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Attendance Report">Attendance Report
                        </div>
                    </a>
                </li> --}}

                <li class="menu-item {{ Session::get('activesubmenu') == 'ta' ? 'highlight blink' : '' }}">
                    <a href="{{ route('teacherAttendance') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="My Attendance">My Attendance</div>
                    </a>
                </li>
            </ul>
        </li>
        <li class="menu-item {{ Session::get('activemenu') == 'exam' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-calendar"></i>
                <div class="text-truncate" data-i18n="Exam">Exam</div>
            </a>
            <ul class="menu-sub">

                <li class="menu-item {{ Session::get('activesubmenu') == 'sm' ? 'active open' : '' }}">
                    <a href="{{ route('subject_marks.index') }}" class="menu-link ">
                        <i class="menu-icon tf-icons bx bx-grid"></i>
                        <div class="text-truncate" data-i18n="Subject Mark">Subject Mark</div>
                    </a>

                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'esmo' ? 'active open' : '' }}">
                    <a href="{{ route('subject_marks_others') }}" class="menu-link ">
                        <i class="menu-icon tf-icons bx bx-grid"></i>
                        <div class="text-truncate" data-i18n="Others Subject Mark">Others Subject Mark</div>
                    </a>

                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'ets' ? 'active open' : '' }}">
                    <a href="{{ route('tabulationSectionTeacher') }}" class="menu-link ">
                        <i class="menu-icon tf-icons bx bx-grid"></i>
                        <div class="text-truncate" data-i18n="Tabulation Sheet">Tabulation Sheet</div>
                    </a>

                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'eact' ? 'active open' : '' }}">
                    <a href="{{ route('academicTranscript') }}" class="menu-link ">
                        <i class="menu-icon tf-icons bx bx-grid"></i>
                        <div class="text-truncate" data-i18n="Academic Transcript">Academic Transcript </div>
                    </a>

                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'pl' ? 'active open' : '' }}">
                    <a href="{{ route('passlistTeacher') }}" class="menu-link ">
                        <i class="menu-icon tf-icons bx bx-grid"></i>
                        <div class="text-truncate" data-i18n=" Pass list"> Pass list </div>
                    </a>

                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'fl' ? 'active open' : '' }}">
                    <a href="{{ route('faillistTeacher') }}" class="menu-link ">
                        <i class="menu-icon tf-icons bx bx-grid"></i>
                        <div class="text-truncate" data-i18n=" Fail list"> Fail list </div>
                    </a>

                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'ml' ? 'active open' : '' }}">
                    <a href="{{ route('meritlistTeacher') }}" class="menu-link ">
                        <i class="menu-icon tf-icons bx bx-grid"></i>
                        <div class="text-truncate" data-i18n="Merit list">Merit list</div>
                    </a>

                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'sma' ? 'active open' : '' }}">
                    <a href="{{ route('studentAttendence') }}" class="menu-link">
                        <i class="menu-icon tf-icons bx bx-grid"></i>
                        <div class="text-truncate" data-i18n="Student Attendence">Student Attendence</div>
                    </a>
                </li>
            </ul>
        </li>

        <li class="menu-item {{ Session::get('activemenu') == 'acac' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-calendar"></i>
                <div class="text-truncate" data-i18n="Academy Activity">Academy Activity</div>
            </a>
            <ul class="menu-sub">

                <li class="menu-item {{ Session::get('activesubmenu') == 'syl' ? 'active open' : '' }}">
                    <a href="{{ route('teacherSyllabus') }}" class="menu-link ">
                        <i class="menu-icon tf-icons bx bx-grid"></i>
                        <div class="text-truncate" data-i18n="Syllabus">Syllabus</div>
                    </a>

                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'lp' ? 'active open' : '' }}">
                    <a href="{{ route('teacherLessonplan') }}" class="menu-link ">
                        <i class="menu-icon tf-icons bx bx-file"></i>
                        <div class="text-truncate" data-i18n="Lesson plan">Lesson plan</div>
                    </a>

                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'yc' ? 'active open' : '' }}">
                    <a href="{{ route('teacherYearCalender') }}" class="menu-link ">
                        <i class="menu-icon tf-icons bx bx-grid"></i>
                        <div class="text-truncate" data-i18n="Year Calender">Year Calender</div>
                    </a>

                </li>

            </ul>
        </li>



        <!-- <li class="menu-item {{ Session::get('activemenu') == 'payment' ? 'active open' : '' }}">
      <a href="javascript:void(0);" class="menu-link menu-toggle">
         <i class="menu-icon tf-icons bx bx-card"></i>
         <div class="text-truncate" data-i18n="Payment">Payment</div>
      </a>
      <ul class="menu-sub">

            <li class="menu-item {{ Session::get('activesubmenu') == 'p' ? 'highlight blink' : '' }}">
               <a href="{{ route('teacherPayment') }}" class="menu-link">
                  <div class="text-truncate" data-i18n="Payment List">Payment List</div>
               </a>
            </li>
      </ul>
   </li> -->
    @endif


    @if (Auth::user()->getMenu('Students', 'module_name'))
        <li class="menu-item {{ Session::get('activemenu') == 'student' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div class="text-truncate" data-i18n="Students">Students</div>
            </a>
            <ul class="menu-sub">
                {{-- @if (Auth::user()->getMenu('students.create', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'se' ? 'highlight blink' : '' }}">
                        <a href="{{ route('students.create') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Students Entry">Students Entry</div>
                        </a>
                    </li>
                @endif --}}
                @if (Auth::user()->getMenu('college-students.create', 'name') && Auth::user()->is_view_user == 0)
                    <li class="menu-item {{ Session::get('activesubmenu') == 'cs' ? 'highlight blink' : '' }}">
                        <a href="{{ route('college-students.create') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Student Admission Form">Student Admission Form</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('students.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'si' ? 'highlight blink' : '' }}">
                        <a href="{{ route('students.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Students Info">Students Info</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('studentXlUpload', 'name') && Auth::user()->is_view_user == 0)
                    <li class="menu-item {{ Session::get('activesubmenu') == 'sxu' ? 'highlight blink' : '' }}">
                        <a href="{{ route('studentXlUpload') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Students Xl Upload">Students Xl Upload</div>
                        </a>
                    </li>
                @endif

                @if (Auth::user()->getMenu('studentXlUpload', 'name') && Auth::user()->is_view_user == 0)
                    <li class="menu-item {{ Session::get('activesubmenu') == 'spu' ? 'highlight blink' : '' }}">
                        <a href="{{ route('studentPIDUpload') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Students PID">Students PID</div>
                        </a>
                    </li>
                @endif

                @if (Auth::user()->getMenu('studentInactiveList', 'name') && Auth::user()->is_view_user == 0)
                    <li class="menu-item {{ Session::get('activesubmenu') == 'isl' ? 'highlight blink' : '' }}">
                        <a href="{{ route('studentInactiveList') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Inactive Student">Inactive Student</div>
                        </a>
                    </li>
                @endif

            </ul>
        </li>
    @endif
    @if (Auth::user()->getMenu('Employees', 'module_name'))
        <li class="menu-item {{ Session::get('activemenu') == 'employee' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div class="text-truncate" data-i18n="Employees">Employees</div>
            </a>
            <ul class="menu-sub">
                @if (Auth::user()->getMenu('employees.create', 'name') && Auth::user()->is_view_user == 0)
                    <li class="menu-item {{ Session::get('activesubmenu') == 'ec' ? 'highlight blink' : '' }}">
                        <a href="{{ route('employees.create') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Employees Add">Employees Add</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('employees.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'ei' ? 'highlight blink' : '' }}">
                        <a href="{{ route('employees.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Employees Info">Employees Info</div>
                        </a>
                    </li>
                @endif
            </ul>
        </li>
    @endif
    @if (Auth::user()->getMenu('Attendance', 'module_name'))

        <li class="menu-item {{ Session::get('activemenu') == 'attendance' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-calendar"></i>
                <div class="text-truncate" data-i18n="Attendance">Attendance</div>
            </a>
            <ul class="menu-sub">
                @if (Auth::user()->getMenu('studentAttendance', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'sa' ? 'highlight blink' : '' }}">
                        <a href="{{ route('studentAttendance') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Student Attendance">Student Attendance</div>
                        </a>
                    </li>
                @endif

                @if (Auth::user()->getMenu('attendance.reconcilation', 'name') && Auth::user()->is_view_user == 0)
                    <li class="menu-item {{ Session::get('activesubmenu') == 'atr' ? 'highlight blink' : '' }}">
                        <a href="{{ route('attendance.reconcilation') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Attendance Reconciliation">Attendance Reconciliation
                            </div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('attendance.report', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'atreport' ? 'highlight blink' : '' }}">
                        <a href="{{ route('attendance.getStudent') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Attendance Report">Attendance Report
                            </div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('allteacherAttendance', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'ta' ? 'highlight blink' : '' }}">
                        <a href="{{ route('allteacherAttendance') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Teacher Attendance">Teacher Attendance</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('staffAttendance', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'st' ? 'highlight blink' : '' }}">
                        <a href="{{ route('staffAttendance') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Staff Attendance">Staff Attendance</div>
                        </a>
                    </li>
                @endif

            </ul>
        </li>
    @endif
    @if (Auth::user()->getMenu('Academy Activity', 'module_name'))
        <li class="menu-item {{ Session::get('activemenu') == 'activity' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-layout"></i>
                <div class="text-truncate" data-i18n="Academy Activity">Academy Activity</div>
            </a>
            <ul class="menu-sub">
                @if (Auth::user()->getMenu('routine.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'rg' ? 'highlight blink' : '' }}">
                        <a href="{{ route('routine.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Class Routine">Class Routine</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('syllabus.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'sb' ? 'highlight blink' : '' }}">
                        <a href="{{ route('syllabus.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Syllabus">Syllabus</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('lessonplan.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'lp' ? 'highlight blink' : '' }}">
                        <a href="{{ route('lessonplan.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Lesson Plan">Lesson Plan</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('year-calendar.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'yc' ? 'highlight blink' : '' }}">
                        <a href="{{ route('year-calendar.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Year Calendar">Year Calendar</div>
                        </a>
                    </li>
                @endif

                <!-- <li class="menu-item {{ Session::get('activesubmenu') == 'rg' ? 'ta' : '' }}">
            <a href="{{ route('teacherassign.index') }}" class="menu-link">
               <div class="text-truncate" data-i18n="Teacher Assign">Teacher Assign</div>
            </a>
         </li>

         <li class="menu-item {{ Session::get('activesubmenu') == 'sp' ? 'highlight blink' : '' }}">
            <a href="{{ route('studentPromot.index') }}" class="menu-link">
               <div class="text-truncate" data-i18n="Student Promot">Student Promot</div>
            </a>
         </li>
         <li class="menu-item {{ Session::get('activesubmenu') == 're' ? 'highlight blink' : '' }}">
            <a href="{{ route('rfid.index') }}" class="menu-link">
               <div class="text-truncate" data-i18n="RFID">RFID Assign</div>
            </a>
         </li> -->
            </ul>
        </li>
    @endif
    @if (Auth::user()->getMenu('SMS', 'module_name') && Auth::user()->is_view_user == 0)
        <li class="menu-item {{ Session::get('activemenu') == 'sms' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-wallet"></i>
                <div class="text-truncate" data-i18n="SMS">SMS</div>
            </a>
            <ul class="menu-sub">
                @if (Auth::user()->getMenu('sms.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'ss' ? 'highlight blink' : '' }}">
                        <a href="{{ route('sms.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="SMS List">SMS List</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('sms.create', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'smsc' ? 'highlight blink' : '' }}">
                        <a href="{{ route('sms.create') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Send SMS">Send SMS</div>
                        </a>
                    </li>
                @endif
                {{-- @if (Auth::user()->getMenu('sms.create_teacher', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'sp' ? 'highlight blink' : '' }}">
                        <a href="{{ route('send_password') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Send Password">Send Password</div>
                        </a>
                    </li>
                @endif --}}
                {{-- @if (Auth::user()->getMenu('sms.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'smss' ? 'highlight blink' : '' }}">
                        <a href="{{ route('sms.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="SMS Student">SMS Student</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('sms.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'smst' ? 'highlight blink' : '' }}">
                        <a href="{{ route('sms.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="SMS Teacher">SMS Teacher</div>
                        </a>
                    </li>
                @endif --}}
                {{-- @if (Auth::user()->getMenu('ssl.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'ssl' ? 'highlight blink' : '' }}">
                        <a href="{{ route('ssl.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="SSL">SSL</div>
                        </a>
                    </li>
                @endif --}}

            </ul>
        </li>
    @endif
    @if (Auth::user()->getMenu('Exam', 'module_name'))
        <li class="menu-item {{ Session::get('activemenu') == 'exam' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-book"></i>
                <div class="text-truncate" data-i18n="Exam">Exam</div>
            </a>
            <ul class="menu-sub">


                <li class="menu-item {{ Session::get('activesubmenu') == 'ex' ? 'highlight blink' : '' }}">
                    <a href="{{ route('exams.index') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Exam">Exam</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'exs' ? 'highlight blink' : '' }}">
                    <a href="{{ route('exam-time-shedules.index') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Exam Time Schedule">Exam Time Schedule</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'smt' ? 'highlight blink' : '' }}">
                    <a href="{{ route('subject_mark_terms.index') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Subject mark terms">Subject mark terms</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'adc' ? 'highlight blink' : '' }}">
                    <a href="{{ route('admitcard') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Admit Card">Admit Card</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'as' ? 'highlight blink' : '' }}">
                    <a href="{{ route('attendanceSheet') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Attendance Sheet">Attendance Sheet</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'cmu' ? 'highlight blink' : '' }}">
                    <a href="{{ route('subject_marks_ct_upload') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="CT/Quiz mark Upload">CT/Quiz mark Upload</div>
                    </a>
                </li>
                @if (Auth::user()->is_view_user == 0)
                    <li class="menu-item {{ Session::get('activesubmenu') == 'sm' ? 'highlight blink' : '' }}">
                        <a href="{{ route('subject_marks.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Subject mark">Subject mark</div>
                        </a>
                    </li>

                    <li class="menu-item {{ Session::get('activesubmenu') == 'sma' ? 'highlight blink' : '' }}">
                        <a href="{{ route('studentAttendence') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Student Attendence">Student Attendence</div>
                        </a>
                    </li>

                    <li class="menu-item {{ Session::get('activesubmenu') == 'os' ? 'highlight blink' : '' }}">
                        <a href="{{ route('other_subject_marks') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Other Subject Mark Entry">Other Subject Mark Entry
                            </div>
                        </a>
                    </li>

                    <li class="menu-item {{ Session::get('activesubmenu') == 'am' ? 'highlight blink' : '' }}">
                        <a href="{{ route('avarageMark') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Avarage Mark">Avarage Mark</div>
                        </a>
                    </li>
                    <li class="menu-item {{ Session::get('activesubmenu') == 'mp' ? 'highlight blink' : '' }}">
                        <a href="{{ route('meritPosition') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Merit Position">Merit Position</div>
                        </a>
                    </li>
                    <li class="menu-item {{ Session::get('activesubmenu') == 'ats' ? 'highlight blink' : '' }}">
                        <a href="{{ route('AutoSection') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Auto Section">Auto Section</div>
                        </a>
                    </li>
                @endif
                <li class="menu-item {{ Session::get('activesubmenu') == 'at' ? 'highlight blink' : '' }}">
                    <a href="{{ route('tabulation.index') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Academic Transcript">Academic Transcript</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'tb' ? 'highlight blink' : '' }}">
                    <a href="{{ route('tabulationSection') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Tabulation">Tabulation</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'pl' ? 'highlight blink' : '' }}">
                    <a href="{{ route('pass_list') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Pass List">Pass List</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'fl' ? 'highlight blink' : '' }}">
                    <a href="{{ route('fail_list') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Fail List">Fail List</div>
                    </a>
                </li>

                <li class="menu-item {{ Session::get('activesubmenu') == 'ml' ? 'highlight blink' : '' }}">
                    <a href="{{ route('merit_list') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Merit list">Merit list</div>
                    </a>
                </li>
                @if (Auth::user()->is_view_user == 0)
                    <li class="menu-item {{ Session::get('activesubmenu') == 'sp' ? 'highlight blink' : '' }}">
                        <a href="{{ route('studentPromotion.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Student Promotion">Student Promotion</div>
                        </a>
                    </li>
                @endif
                <li class="menu-item {{ Session::get('activesubmenu') == 'swsr' ? 'active open' : '' }}">
                    <a href="{{ route('subjectWiseStudentResult') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Subject-Based Result">Subject-Based Result
                        </div>
                    </a>
                </li>

            </ul>

        </li>
    @endif
    @if (Auth::user()->getMenu('Report', 'module_name'))
        <li class="menu-item {{ Session::get('activemenu') == 'report' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-calendar"></i>
                <div class="text-truncate" data-i18n="Report">Report</div>
            </a>
            <ul class="menu-sub">

                @if (Auth::user()->getMenu('studentAttendanceReport', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'satt' ? 'highlight blink' : '' }}">
                        <a href="{{ route('studentAttendanceReport') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Student Attendance">Student Attendance</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('teacherAttendanceReport', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'tatt' ? 'highlight blink' : '' }}">
                        <a href="{{ route('teacherAttendanceReport') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Teacher Attendance">Teacher Attendance</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('staffAttendanceReport', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'statt' ? 'highlight blink' : '' }}">
                        <a href="{{ route('staffAttendanceReport') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Staf Attendance">Staf Attendance</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('getstudent', 'name'))
                    <li
                        class="menu-item {{ Session::get('activesubmenu') == 'atsreport' ? 'highlight blink' : '' }}">
                        <a href="{{ route('getstudent') }}" class="menu-link d-flex align-items-center">
                            <div class="box-icon me-2">
                                {{-- <i class="fa fa-chart-line"></i>  --}}
                            </div>
                            <div class="text-truncate" data-i18n="Attendance Report">Attendance Report</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('averageMarkReport', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'mr' ? 'highlight blink' : '' }}">
                        <a href="{{ route('average.mark.report') }}" class="menu-link d-flex align-items-center">
                            <div class="box-icon me-2">
                                {{-- <i class="fa fa-chart-line"></i>  --}}
                            </div>
                            <div class="text-truncate" data-i18n="Average Mark Report">Average Mark Report</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('averageFailStudentReport', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'afsr' ? 'highlight blink' : '' }}">
                        <a href="{{ route('average.fail.report') }}" class="menu-link d-flex align-items-center">
                            <div class="box-icon me-2">
                                {{-- <i class="fa-solid fa-scale-unbalanced-flip"></i>  --}}
                            </div>
                            <div class="text-truncate" data-i18n="Fail Student Report">
                                Average Fail Student Report
                            </div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('averageHighestMarkReport', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'ahmr' ? 'highlight blink' : '' }}">
                        <a href="{{ route('average.highest.mark.report') }}"
                            class="menu-link d-flex align-items-center">
                            <div class="box-icon me-2">
                                {{-- <i class="fa-solid fa-ranking-star"></i>  --}}
                            </div>
                            <div class="text-truncate" data-i18n="Highest Mark Report">
                                Average Highest Mark Report
                            </div>
                        </a>
                    </li>
                @endif

                @if (Auth::user()->getMenu('averageStudentAttendanceReport', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'astr' ? 'highlight blink' : '' }}">
                        <a href="{{ route('average.student.attendance.report') }}"
                            class="menu-link d-flex align-items-center">
                            <div class="box-icon me-2">
                                {{-- <i class="fa-solid fa-chart-pie"></i>  --}}
                            </div>
                            <div class="text-truncate" data-i18n="Student Attendance Report">
                                Average Student Attendance Report
                            </div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('averageStudentAttendanceReport', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'atts' ? 'highlight blink' : '' }}">
                        <a href="{{ route('student.attendance.statistics') }}"
                            class="menu-link d-flex align-items-center">
                            <div class="box-icon me-2">
                                {{-- <i class="fa-solid fa-chart-pie"></i>  --}}
                            </div>
                            <div class="text-truncate" data-i18n="Attendance Statistics">
                                Attendance Statistics
                            </div>
                        </a>
                    </li>
                @endif


                {{-- <li class="menu-item {{(Session::get('activesubmenu')=='le')?'highlight blink':''}}">
            <a href="#" class="menu-link">
               <div class="text-truncate" data-i18n="Leave">Leave</div>
            </a>
         </li> --}}
                {{-- <li class="menu-item {{(Session::get('activesubmenu')=='str')?'highlight blink':''}}">
            <a href="#" class="menu-link">
               <div class="text-truncate" data-i18n="Student Transfer">Student Transfer</div>
            </a>
         </li>

         <li class="menu-item {{(Session::get('activesubmenu')=='re')?'highlight blink':''}}">
            <a href="#" class="menu-link">
               <div class="text-truncate" data-i18n="Result">Result</div>
            </a>
         </li> --}}


            </ul>
        </li>
    @endif
    @if (Auth::user()->getMenu('Finance', 'module_name'))
        <li class="menu-item {{ Session::get('activemenu') == 'finance' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-money"></i>
                <div class="text-truncate" data-i18n="Finance">Finance</div>
            </a>
            <ul class="menu-sub">
                @if (Auth::user()->getMenu('studentXLFeeUpload', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'sxfu' ? 'highlight blink' : '' }}">
                        <a href="{{ route('studentXLFeeUpload') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Student XL Fee Upload">Student XL Fee Upload</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('studentFeeGenerate', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'sfg' ? 'highlight blink' : '' }}">
                        <a href="{{ route('studentFeeGenerate') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Students Generate">Students Generate</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('feeHeadAmountView', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'fhav' ? 'highlight blink' : '' }}">
                        <a href="{{ route('feeHeadAmountView') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Fee Head Amount">Fee Head Amount</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('fees.create', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'sf' ? 'highlight blink' : '' }}">
                        <a href="{{ route('fees.create') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Students Fee">Students Fee</div>
                        </a>
                    </li>
                @endif
                <li class="menu-item {{ Session::get('activesubmenu') == 'fi' ? 'highlight blink' : '' }}">
                    <a href="{{ route('fine.index') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Fine">Fine</div>
                    </a>
                </li>
                <!-- @if (Auth::user()->getMenu('employeeSalaryGenerate', 'name'))
<li class="menu-item {{ Session::get('activesubmenu') == 'esg' ? 'highlight blink' : '' }}">
                                <a href="{{ route('employeeSalaryGenerate') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Employee Salary Generate">Employee Salary Generate</div>
                                </a>
                                </li>
@endif
                                @if (Auth::user()->getMenu('employeeSalary', 'name'))
<li class="menu-item {{ Session::get('activesubmenu') == 'es' ? 'highlight blink' : '' }}">
                                <a href="{{ route('employeeSalary') }}" class="menu-link">
                                <div class="text-truncate" data-i18n="Employee Salary">Employee Salary</div>
                                </a>
                                </li>
@endif -->
                <!-- <li class="menu-item {{ Session::get('activesubmenu') == 'se' ? 'highlight blink' : '' }}">
                    <a href="{{ route('evaluation.index') }}" class="menu-link">
               <div class="text-truncate" data-i18n="Student Evaluation">Student Evaluation</div>
                </a>
                </li> -->
                @if (Auth::user()->getMenu('feeHeadamount', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'fha' ? 'highlight blink' : '' }}">
                        <a href="{{ route('feeHeadamount') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Category wise Amount">Category wise Amount</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('fees.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'fh' ? 'highlight blink' : '' }}">
                        <a href="{{ route('fees.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Fee Head">Fee Head</div>
                        </a>
                    </li>
                @endif
                <li class="menu-item {{ Session::get('activesubmenu') == 'sw' ? 'highlight blink' : '' }}">
                    <a href="{{ route('feeClassWiseUpdate', 1) }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Tuition Fee">Tuition Fee</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'sc' ? 'highlight blink' : '' }}">
                    <a href="{{ route('sessionCharge.index') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Session Charge">Session Charge</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == '3' ? 'highlight blink' : '' }}">
                    <a href="{{ route('feeClassWiseUpdate', 3) }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Admission Fee">Admission Fee</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == '36' ? 'highlight blink' : '' }}">
                    <a href="{{ route('feeClassWiseUpdate', 36) }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Evaluation Test">Evaluation Test </div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == '37' ? 'highlight blink' : '' }}">
                    <a href="{{ route('feeClassWiseUpdate', 37) }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Board Fee">Board Fee</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == '13' ? 'highlight blink' : '' }}">
                    <a href="{{ route('feeClassWiseUpdate', 13) }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Uniform">Uniform</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == '5' ? 'highlight blink' : '' }}">
                    <a href="{{ route('feeClassWiseUpdate', 5) }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Absent Fee">Absent Fee</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == '4' ? 'highlight blink' : '' }}">
                    <a href="{{ route('feeClassWiseUpdate', 4) }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Late Fee">Late Fee</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == '44' ? 'highlight blink' : '' }}">
                    <a href="{{ route('feeSutdentWiseEntry', 44) }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Others Fee">Others Fee</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == '45' ? 'highlight blink' : '' }}">
                    <a href="{{ route('feeSutdentWiseEntry', 45) }}" class="menu-link">
                        <div class="text-truncate" data-i18n="TC">TC</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == '47' ? 'highlight blink' : '' }}">
                    <a href="{{ route('feeSutdentWiseEntry', 47) }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Re-test Fee">Re-test Fee</div>
                    </a>
                </li>

                <!-- <li class="menu-item {{ Session::get('activesubmenu') == 'ef' ? 'highlight blink' : '' }}">
                    <a href="{{ route('examfee.index') }}" class="menu-link">
                    <div class="text-truncate" data-i18n="Exam Fee">Exam Fee</div>
                    </a>
                </li> -->
                <li class="menu-item {{ Session::get('activesubmenu') == 'sw' ? 'highlight blink' : '' }}">
                    <a href="{{ route('feeClassWiseUpdate', 29) }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Student Welfare">Student Welfare</div>
                    </a>
                </li>
                <!-- <li class="menu-item {{ Session::get('activesubmenu') == 'bf' ? 'highlight blink' : '' }}">
                    <a href="{{ route('feeClassWiseUpdate', 37) }}" class="menu-link">
                    <div class="text-truncate" data-i18n="Board Fee">Board Fee</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'gc' ? 'highlight blink' : '' }}">
                    <a href="{{ route('governmentCharge.index') }}" class="menu-link">
                    <div class="text-truncate" data-i18n="Government Charge">Government Charge</div>
                    </a>
                </li> -->
                <!-- <li class="menu-item {{ Session::get('activesubmenu') == 'tf' ? 'highlight blink' : '' }}">
                    <a href="{{ route('inactiveFine.index') }}" class="menu-link">
                    <div class="text-truncate" data-i18n="Inactive Fine & Others">Inactive Fine & Others</div>
                    </a>
                </li> -->

                <li class="menu-item {{ Session::get('activesubmenu') == '35' ? 'highlight blink' : '' }}">
                    <a href="{{ route('feeClassWiseUpdate', 35) }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Registration Fee">Registration Fee</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == '39' ? 'highlight blink' : '' }}">
                    <a href="{{ route('feeClassWiseUpdate', 39) }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Cub Scout">Cub Scout</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == '38' ? 'highlight blink' : '' }}">
                    <a href="{{ route('feeClassWiseUpdate', 38) }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Rover Scout">Rover Scout</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == '40' ? 'highlight blink' : '' }}">
                    <a href="{{ route('feeClassWiseUpdate', 40) }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Ranger Guide">Ranger Guide</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == '32' ? 'highlight blink' : '' }}">
                    <a href="{{ route('feeClassWiseUpdate', 32) }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Red Crecent">Red Crecent</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == '33' ? 'highlight blink' : '' }}">
                    <a href="{{ route('feeClassWiseUpdate', 33) }}" class="menu-link">
                        <div class="text-truncate" data-i18n="BNCC">BNCC</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == '41' ? 'highlight blink' : '' }}">
                    <a href="{{ route('feeClassWiseUpdate', 41) }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Air Scout">Air Scout</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == '42' ? 'highlight blink' : '' }}">
                    <a href="{{ route('feeClassWiseUpdate', 42) }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Govt. Retd Benefit">Govt. Retd Benefit</div>
                    </a>
                </li>

                <!-- <li class="menu-item {{ Session::get('activesubmenu') == 'rac' ? 'highlight blink' : '' }}">
                    <a href="{{ route('readmission.index') }}" class="menu-link">
                    <div class="text-truncate" data-i18n="Re Admission Condition">Re Admission Condition</div>
                    </a>
                </li> -->
                <!-- <li class="menu-item {{ Session::get('activesubmenu') == 'ec' ? 'highlight blink' : '' }}">
                    <a href="{{ route('emisCharge.index') }}" class="menu-link">
                    <div class="text-truncate" data-i18n="Emis Charge">Emis Charge</div>
                    </a>
                </li> -->




            </ul>
        </li>
    @endif
    @if (Auth::user()->getMenu('Admission', 'module_name'))
        <li class="menu-item {{ Session::get('activemenu') == 'admission' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div class="text-truncate" data-i18n="Admission">Admission</div>
            </a>
            <ul class="menu-sub">
                @if (Auth::user()->getMenu('boardList', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'bl' ? 'highlight blink' : '' }}">
                        <a href="{{ route('boardList') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Board List">Board List</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('kgAdmitList', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'kl' ? 'highlight blink' : '' }}">
                        <a href="{{ route('kgAdmitList') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Kg Admit List">Kg Admit List</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('kgAdmitLottery', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'KAL' ? 'highlight blink' : '' }}">
                        <a href="{{ route('kgAdmitLottery') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Kg Lottery">Kg Lottery</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('showStudentCounts', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'ks' ? 'highlight blink' : '' }}">
                        <a href="{{ route('showStudentCounts') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Student Statistics">Student Statistics</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('admissionstatus', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'cas' ? 'highlight blink' : '' }}">
                        <a href="{{ route('admissionstatus') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="College Student Statistics">College Student
                                Statistics</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('admissionlist.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'al' ? 'highlight blink' : '' }}">
                        <a href="{{ route('admissionlist.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Applicant List">Applicant List</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('admissionOpen', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'oa' ? 'highlight blink' : '' }}">
                        <a href="{{ route('admissionOpen') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Open Admission">Open Admission </div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('sectionWiseStudent', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'scws' ? 'highlight blink' : '' }}">
                        <a href="{{ route('sectionWiseStudent') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Section Wise Student">Section Wise Student</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('admissionIdCard', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'adc' ? 'highlight blink' : '' }}">
                        <a href="{{ route('admissionIdCard') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="ID Card">ID Card</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('subjectWiseStudent', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'sws' ? 'highlight blink' : '' }}">
                        <a href="{{ route('subjectWiseStudent') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Subject Wise Student">Subject Wise Student</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('showCertificateList', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'scl' ? 'highlight blink' : '' }}">
                        <a href="{{ route('showCertificateList') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="TC">TC</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('showCertificate', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'tcf' ? 'highlight blink' : '' }}">
                        <a href="{{ route('transferCertificate') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Transfer Certificate">Transfer Certificate Form
                            </div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('boardResult', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'brxu' ? 'highlight blink' : '' }}">
                        <a href="{{ route('boardResult') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Board Result">Board Result</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('showCertificate', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'tml' ? 'highlight blink' : '' }}">
                        <a href="{{ route('testimonial.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Testimonial">Testimonial</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('collegeAdmission', 'name') && Auth::user()->is_view_user == 0)
                    <!-- <li class="menu-item {{ Session::get('activemenu') == 'na' ? 'active open' : '' }}">
                    <a href="{{ route('collegeAdmission') }}" class="menu-link ">
                        <i class="menu-icon tf-icons bx bx-file"></i>
                        <div class="text-truncate" data-i18n="New Admission">New Admission</div>
                    </a>

                </li> -->
                    <li class="menu-item {{ Session::get('activesubmenu') == 'na' ? 'highlight blink' : '' }}">
                        <a href="{{ route('collegeAdmission') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="New Admission">New Admission</div>
                        </a>
                    </li>
                @endif
            </ul>
        </li>
    @endif

    {{-- <li class="menu-item {{(Session::get('activemenu')=='fi')?'active open':''}}">
      <a href="javascript:void(0);" class="menu-link menu-toggle">
         <i class="menu-icon tf-icons bx bx-credit-card"></i>

         <div class="text-truncate" data-i18n="Financial">Financial</div>
      </a>
      <ul class="menu-sub">

         <li class="menu-item {{(Session::get('activesubmenu')=='sfe')?'highlight blink':''}}">
            <a href="{{route('students.index')}}" class="menu-link">
               <div class="text-truncate" data-i18n="Students Fee">Student Fee</div>
            </a>
         </li>
         <li class="menu-item {{(Session::get('activesubmenu')=='tsa')?'highlight blink':''}}">
            <a href="{{route('students.index')}}" class="menu-link">
               <div class="text-truncate" data-i18n="Teacher Salary">Teacher Salary</div>
            </a>
         </li>
         <li class="menu-item {{(Session::get('activesubmenu')=='ssa')?'highlight blink':''}}">
            <a href="{{route('students.index')}}" class="menu-link">
               <div class="text-truncate" data-i18n="Staff Salary">Staff Salary</div>
            </a>
         </li>
         <li class="menu-item {{(Session::get('activesubmenu')=='ssa')?'highlight blink':''}}">
            <a href="{{route('students.index')}}" class="menu-link">
               <div class="text-truncate" data-i18n="Expanse">Expanse</div>
            </a>
         </li>
      </ul>
   </li> --}}

    @if (Auth::user()->getMenu('Class', 'module_name'))
        <li class="menu-item {{ Session::get('activemenu') == 'class' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-grid"></i>
                <div class="text-truncate" data-i18n="Class">Class</div>
            </a>
            <ul class="menu-sub">
                @if (Auth::user()->getMenu('classes.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'cl' ? 'highlight blink' : '' }}">
                        <a href="{{ route('classes.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Class List">Class List</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('section.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'sc' ? 'highlight blink' : '' }}">
                        <a href="{{ route('section.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Section">Section</div>
                        </a>
                    </li>
                @endif

                @if (Auth::user()->getMenu('subjectmapping.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'sm' ? 'highlight blink' : '' }}">
                        <a href="{{ route('subjectmapping.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Subject Mapping">Subject Mapping</div>
                        </a>
                    </li>
                @endif
            </ul>
        </li>
    @endif
    @if (Auth::user()->getMenu('Finance Report', 'module_name'))
        <li class="menu-item {{ Session::get('activemenu') == 'finance-report' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-money"></i>
                <div class="text-truncate" data-i18n="Finance Report">Finance Report</div>
            </a>
            <ul class="menu-sub">


                <li class="menu-item {{ Session::get('activesubmenu') == 'dfc' ? 'highlight blink' : '' }}">
                    <a href="{{ route('feeCollection') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Fee Collection">Daily Fee Collection</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'otf' ? 'highlight blink' : '' }}">
                    <a href="{{ route('outstandingTuitionFee') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Outstanding Tuition Fee">Outstanding Tuition Fee</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'oad' ? 'highlight blink' : '' }}">
                    <a href="{{ route('outstandingDue') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Outstanding All Due">Outstanding All Due</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'otfs' ? 'highlight blink' : '' }}">
                    <a href="{{ route('outstandingTuitionFeeSummary') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Outstanding Tuition Fee Summary">Outstanding Tuition Fee
                            Summary</div>
                    </a>
                </li>
            </ul>

        </li>
    @endif

    @if (Auth::user()->getMenu('Academy Settings', 'module_name') && Auth::user()->is_view_user == 0)
        <li class="menu-item {{ Session::get('activemenu') == 'setting' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-cog"></i>
                <div class="text-truncate" data-i18n="Academy Settings">Academy Settings</div>
            </a>
            <ul class="menu-sub">
                @if (Auth::user()->getMenu('category.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'cat' ? 'highlight blink' : '' }}">
                        <a href="{{ route('category.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Category">Category</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('version.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'vr' ? 'highlight blink' : '' }}">
                        <a href="{{ route('version.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Version">Version</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('session.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'ss' ? 'highlight blink' : '' }}">
                        <a href="{{ route('session.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Session">Session</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('branch.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'br' ? 'highlight blink' : '' }}">
                        <a href="{{ route('branch.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Branch">Branch</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('shift.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'sh' ? 'highlight blink' : '' }}">
                        <a href="{{ route('shift.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Shift">Shift</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('group.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'gu' ? 'highlight blink' : '' }}">
                        <a href="{{ route('group.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Group">Group</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('subject.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'su' ? 'highlight blink' : '' }}">
                        <a href="{{ route('subject.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Subject">Subject</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('designation.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'de' ? 'highlight blink' : '' }}">
                        <a href="{{ route('designation.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Designation">Designation</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('degree.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'deg' ? 'highlight blink' : '' }}">
                        <a href="{{ route('degree.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Degree">Degree</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('discipline.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'di' ? 'highlight blink' : '' }}">
                        <a href="{{ route('discipline.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Discipline">Discipline</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('specialization.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'sp' ? 'highlight blink' : '' }}">
                        <a href="{{ route('specialization.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Specialization">Specialization</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('house.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'ho' ? 'highlight blink' : '' }}">
                        <a href="{{ route('house.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="House">House</div>
                        </a>
                    </li>
                @endif
            </ul>
        </li>
    @endif

    @if (Auth::user()->getMenu('Leave', 'module_name') && Auth::user()->is_view_user == 0)
        <li class="menu-item {{ Session::get('activemenu') == 'leave' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-card"></i>
                <div class="text-truncate" data-i18n="Leave">Leave</div>
            </a>
            <ul class="menu-sub">

                <li class="menu-item {{ Session::get('activesubmenu') == 'lv' ? 'highlight blink' : '' }}">
                    <!-- <a href="#" class="menu-link"> -->
                    <a href="{{ route('documents.index') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Leave View">Leave View</div>
                    </a>
                </li>
                <li class="menu-item {{ Session::get('activesubmenu') == 'lva' ? 'highlight blink' : '' }}">
                    <!-- <a href="#" class="menu-link"> -->
                    <a href="{{ route('documents.create') }}" class="menu-link">
                        <div class="text-truncate" data-i18n="Leave Apply">Leave Apply</div>
                    </a>
                </li>
            </ul>
        </li>
    @endif

    @if (Auth::user()->getMenu('Disciplinary', 'module_name') && Auth::user()->is_view_user == 0)
        <li class="menu-item {{ Session::get('activemenu') == 'disciplinary' ? 'active open' : '' }}">
            <a href="{{ route('disciplinary-issues.index') }}" class="menu-link ">
                <i class="menu-icon tf-icons bx bx-error"></i> <!-- Updated Icon -->
                <div class="text-truncate" data-i18n="Disciplinary Issues">Disciplinary Issues</div>
            </a>
        </li>
    @endif


    @if (Auth::user()->getMenu('Efile', 'module_name') && Auth::user()->is_view_user == 0)
        <li class="menu-item {{ Session::get('activemenu') == 'efile' ? 'active open' : '' }}">
            <a href="{{ route('e-file.index') }}" class="menu-link ">
                <i class="menu-icon tf-icons bx bx-file"></i> <!-- Updated Icon -->
                <div class="text-truncate" data-i18n="E File">E File</div>
            </a>
        </li>
    @endif


    @if (Auth::user()->getMenu('Elibrary', 'module_name') && Auth::user()->is_view_user == 0)
        <li class="menu-item {{ Session::get('activemenu') == 'elibrary' ? 'active open' : '' }}">
            <a href="{{ route('e-library.index') }}" class="menu-link ">
                <i class="menu-icon tf-icons bx bx-book"></i> <!-- Updated Icon -->
                <div class="text-truncate" data-i18n="E Library">E Library</div>
            </a>
        </li>
    @endif


    @if (Auth::user()->getMenu('AssetAndInventory', 'module_name'))
        <li class="menu-item {{ Session::get('activemenu') == 'assetandinventory' ? 'active open' : '' }}">
            <a href="{{ route('asset-inventory.index') }}" class="menu-link ">
                <i class="menu-icon tf-icons bx bx-archive"></i> <!-- Updated Icon -->
                <div class="text-truncate" data-i18n="Asset and Inventory">Asset and Inventory</div>
            </a>
        </li>
    @endif


    @if (Auth::user()->getMenu('Front Pages', 'module_name') && Auth::user()->is_view_user == 0)
        <!-- Front Pages -->
        <li class="menu-item {{ Session::get('activemenu') == 'website' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class='menu-icon tf-icons bx bx-store'></i>
                <div class="text-truncate" data-i18n="Front Pages">Front Pages</div>
            </a>
            <ul class="menu-sub">
                @if (Auth::user()->getMenu('pages.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'pg' ? 'highlight blink' : '' }}">
                        <a href="{{ route('pages.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Pages">Pages</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('slider.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'sl' ? 'highlight blink' : '' }}">
                        <a href="{{ route('slider.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Slider">Slider</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('notice-type.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'nt' ? 'highlight blink' : '' }}">
                        <a href="{{ route('notice-type.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Notice type">Notice type</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('notice.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'no' ? 'highlight blink' : '' }}">
                        <a href="{{ route('notice.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Notice">Notice</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('articles.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'at' ? 'highlight blink' : '' }}">
                        <a href="{{ route('articles.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Articles">Articles</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('gallery-type.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'gt' ? 'highlight blink' : '' }}">
                        <a href="{{ route('gallery-type.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Gallery Type">Gallery Type</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('gallery.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'ga' ? 'highlight blink' : '' }}">
                        <a href="{{ route('gallery.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Gallery">Gallery</div>
                        </a>
                    </li>
                @endif

            </ul>
        </li>
    @endif
    @if (Auth::user()->getMenu('Users', 'module_name') && Auth::user()->is_view_user == 0)
        <li class="menu-item {{ Session::get('activemenu') == 'users' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div class="text-truncate" data-i18n="Users">Users</div>
            </a>
            <ul class="menu-sub">
                @if (Auth::user()->getMenu('users.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'ul' ? 'highlight blink' : '' }}">
                        <a href="{{ route('users.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Users List">Users List</div>
                        </a>
                    </li>
                @endif
                {{-- @if (Auth::user()->getMenu('parentUsercreate', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'uc' ? 'highlight blink' : '' }}">
                        <a href="{{ route('parentUserCreate') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Student User Create">Student User Create</div>
                        </a>
                    </li>
                @endif --}}
                @if (Auth::user()->getMenu('roles.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'ur' ? 'highlight blink' : '' }}">
                        <a href="{{ route('roles.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Roles List">Roles List</div>
                        </a>
                    </li>
                @endif
                @if (Auth::user()->getMenu('permissions.index', 'name'))
                    <li class="menu-item {{ Session::get('activesubmenu') == 'pr' ? 'highlight blink' : '' }}">
                        <a href="{{ route('permissions.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Roles Permissions">Roles Permissions</div>
                        </a>
                    </li>
                @endif

            </ul>
        </li>
    @endif
    @if (Auth::user()->group_id == 8 || Auth::user()->group_id == 2)
        <li class="menu-item {{ Session::get('activemenu') == 'reconcilation' ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div class="text-truncate" data-i18n="Attendance Reconcilation">Attendance Reconcilation</div>
            </a>
            <ul class="menu-sub">
                @if (Auth::user()->getMenu('reconcilation.index', 'name') || Auth::user()->group_id == 8 || Auth::user()->group_id == 2)
                    <li
                        class="menu-item {{ Session::get('activesubmenu') == 'reconcilation' ? 'highlight blink' : '' }}">
                        <a href="{{ route('reconcilation.index') }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Reconcilation Date">Reconcilation Date</div>
                        </a>
                    </li>
                @endif

                @if (Auth::user()->getMenu('reconcilation.show', 'name') || Auth::user()->group_id == 8 || Auth::user()->group_id == 2)
                    <li
                        class="menu-item {{ Session::get('activesubmenu') == 'reconcilation-show' ? 'highlight blink' : '' }}">
                        <a href="{{ route('reconcilation.show', 0) }}" class="menu-link">
                            <div class="text-truncate" data-i18n="Reconcilation Report">Reconcilation Report</div>
                        </a>
                    </li>
                @endif


            </ul>
        </li>
    @endif

    @if (Auth::user()->group_id == 8)
        <li class="menu-item {{ Session::get('activesubmenu') == 'si' ? 'active blink' : '' }}">
            <a href="{{ route('students.index') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div class="text-truncate" data-i18n="Students Info">Students Info</div>
            </a>
        </li>
        <li class="menu-item {{ Session::get('activesubmenu') == 'spu' ? 'active blink' : '' }}">
            <a href="{{ route('studentPIDUpload') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-wallet"></i>
                <div class="text-truncate" data-i18n="Students Payment ID">Students Payment ID</div>
            </a>
        </li>
    @endif


    @if (Auth::user()->group_id == 7 || Auth::user()->group_id == 2)
        <li class="menu-item {{ Session::get('activesubmenu') == 'studentidcard' ? 'highlight blink' : '' }}">
            <a href="{{ route('studentIDCards') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div class="text-truncate" data-i18n="Student ID">Student ID</div>
            </a>
        </li>
    @endif


</ul>
