<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <style>
        .card {
            box-shadow: 0 4px 8px 0 rgb(0, 149, 221);
            max-width: 300px;
            margin: auto;
            text-align: center;
            font-family: arial;

        }

        .title {
            color: grey;
            font-size: 12px;
        }



        a {
            text-decoration: none;
            font-size: 12px;
            color: black;
        }


        h4,
        p {
            margin-block-start: 5px !important;
            margin-block-end: 5px !important;
        }

        .btn {
            --bs-btn-padding-x: 1.25rem;
            --bs-btn-padding-y: 0.4375rem;
            --bs-btn-font-family: ;
            --bs-btn-font-size: 0.9375rem;
            --bs-btn-font-weight: 400;
            --bs-btn-line-height: 1.53;
            --bs-btn-color: var(--bs-body-color);
            --bs-btn-bg: transparent;
            --bs-btn-border-width: var(--bs-border-width);
            --bs-btn-border-color: transparent;
            --bs-btn-border-radius: var(--bs-border-radius);
            --bs-btn-hover-border-color: transparent;
            --bs-btn-box-shadow: none;
            --bs-btn-disabled-opacity: 0.65;
            --bs-btn-focus-box-shadow: 0 0 0 0.05rem rgba(var(--bs-btn-focus-shadow-rgb), .5);
            display: inline-block;
            padding: var(--bs-btn-padding-y) var(--bs-btn-padding-x);
            font-family: var(--bs-btn-font-family);
            font-size: var(--bs-btn-font-size);
            font-weight: var(--bs-btn-font-weight);
            line-height: var(--bs-btn-line-height);
            color: var(--bs-btn-color);
            text-align: center;
            vertical-align: middle;
            cursor: pointer;
            user-select: none;
            border: var(--bs-btn-border-width) solid var(--bs-btn-border-color);
            border-radius: var(--bs-btn-border-radius);
            background-color: var(--bs-btn-bg);
            transition: all .2s ease-in-out;
        }

        .btn-outline-primary {
            color: #696cff;
            border-color: #696cff;
            border: 1px solid;
            background: rgba(0, 0, 0, 0);
        }

        .btn {
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        @media print {
            .no-print {
                display: none !important;
            }

            p {
                line-height: 5px !important;
            }
        }
    </style>
</head>

<body>


    @foreach ($studentdata as $key => $student)
        <div class="card" id="card">
            <h2 style="text-align:center" style="margin-top: 5px;">Temporary ID Card</h2>
            <img src="{{ $student->photo }}" alt="John" style="width:auto;height: 70px;margin-top: 10px;">
            <h4>Full Name: {{ $student->first_name }}</h4>
            <p>
                Roll:
                {{ $student->activity->class_code == 0 && isset($student->activity->roll) && strlen($student->activity->roll) == 8 ? substr($student->activity->roll, -4) : $student->activity->roll ?? 'N/A' }}
            </p>
            <!-- <p>{!! $student->qrCode !!}</p> -->

            <p>Class: {{ $student->activity->class_code == 0 ? 'KG' : $student->activity->class_code }}</p>
            <p>Section: {{ $student->activity->section->section_name ?? '' }}</p>
            <p>Group: {{ $student->activity->group->group_name ?? '' }}</p>
            <p>Blood Group: {{ $student->blood ?? '' }}</p>

            <!-- <div style="margin: 24px 0;">
    <a href="#"><i class="fa fa-dribbble"></i></a>
    <a href="#"><i class="fa fa-twitter"></i></a>
    <a href="#"><i class="fa fa-linkedin"></i></a>
    <a href="#"><i class="fa fa-facebook"></i></a>
  </div> -->
            <p style="background-color: rgb(0,149,221);padding: 10px;color: white">BAF Shaheen College Dhaka</p>
        </div>
    @endforeach


</body>

</html>
