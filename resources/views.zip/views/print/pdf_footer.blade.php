

    <table class="x-footer">
       
        <tr style="border:0px">
            <td style="width: 50%;text-align: left;" class="f11">bafsd.edu.bd | </td>
            <td style="text-align: right;">Page 
                    <span class=" pageNo_en f11">({PAGENO}/{nb})</span>
            </td>
        </tr>

    </table>


    <!-- <div class="pageno-wrapper even">
        <p>adp.plancomm.gov.bd </p>
        <div class="pageno-corner"></div>
        <div class="pageno-bar"></div>
        <div class="pageno-circle">
            <a name="page-{PAGENO}">{PAGENO}</a>
        </div>
    </div> -->

