<table class="x-header" style="border:0px">
        <tbody>

            <tr>
                <td style="width:25%;border:0px;padding:0px;margin:0px;">
                    <img src="{{asset('images/backend_images/50years.png')}}"
                        style="height: 80px;float:left;padding:0px;margin:0px 0px 0px -6px;" />
                </td>
                <td style="width:50%;border:0px;text-align:center;font-size:16px;font-weight:bold ">

                    @if($language == 'bn')
                    গণপ্রজাতন্ত্রী বাংলাদেশ সরকার<br />পরিকল্পনা কমিশন<br />কার্যক্রম বিভাগ
                    @else
                    People's Republic of Bangladesh<br />Planning Commission<br />Programming Division
                    @endif
                </td>
                <td style="width:25%;border:0px;margin:0px;">
                    <img src="{{asset('images/backend_images/Dailysun-2020-01-13-43.jpg')}}"
                        style="height: 80px;float:right;padding-left:90px;" />
                </td>
            </tr>
        </tbody>
    </table>